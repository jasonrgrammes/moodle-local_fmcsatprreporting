<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR btw credentials integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_login();
$context = context_system::instance();
require_capability('moodle/site:config', $context);
if (!is_siteadmin()) {
    throw new required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
}
$url = new moodle_url('/local/govreporting/btw_credentials.php');
$back = new moodle_url('/admin/settings.php', ['section' => 'local_govreporting_config']);
$providerid = optional_param('providerid', 0, PARAM_INT);
$provider = $providerid ? \local_govreporting\provider_manager::get($providerid) : null;
$owner = $provider ? \local_govreporting\provider_manager::credential_owner($provider) : null;
if ($owner && $owner->id !== $provider->id) {
    redirect(new moodle_url($url, ['providerid' => $owner->id]));
}
$PAGE->set_context($context);
$PAGE->set_url($url);
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('text_d88f6d2a3111', 'local_govreporting'));
$PAGE->set_heading(get_string('text_d88f6d2a3111', 'local_govreporting'));
/**
 * Local govreporting btw certificate form for FMCSA TPR workflows.
 */
class local_govreporting_btw_certificate_form extends moodleform {
    /**
     * Define the form controls.
     *
     * @return void
     */
    public function definition() {
        $m = $this->_form;
        $providers = [];foreach (\local_govreporting\provider_manager::all() as $p) {
            $owner = \local_govreporting\provider_manager::credential_owner($p);
            if ($owner && $owner->id === $p->id) {
                $providers[$p->id] = $p->name;
            }
        }
        $m->addElement('select', 'providerid', get_string('text_40f3cd24e32f', 'local_govreporting'), $providers);
        $m->setType('providerid', PARAM_INT);
        $m->addElement(
            'select',
            'mode',
            get_string(
                'text_17a150393bd1',
                'local_govreporting'
            ),
            ['test' => 'Test',
            'production' => 'Production']
        );
        $m->setDefault('mode', 'test');
        $m->addElement(
            'advcheckbox',
            'officialtest',
            get_string(
                'text_2a8ebd43b99d',
                'local_govreporting'
            ),
            get_string(
                'text_fe6bd3955574',
                'local_govreporting'
            )
        );
        $m->addElement('text', 'issuer', get_string('text_2df791167380', 'local_govreporting'));
        $m->setType('issuer', PARAM_TEXT);
        $m->addRule('issuer', 'Required', 'required', null, 'client');
        $m->addElement(
            'filepicker',
            'pfx',
            get_string(
                'text_71bb8b3b4ee5',
                'local_govreporting'
            ),
            null,
            ['accepted_types' => ['.pfx',
             '.p12'],
            'maxbytes' => 2097152]
        );
        $m->addRule('pfx', 'Required', 'required', null, 'client');
        $m->addElement('password', 'pfxpassword', get_string('text_1d65a101ea13', 'local_govreporting'));
        $m->setType('pfxpassword', PARAM_RAW);
        $this->add_action_buttons(true, get_string('text_6bcacc410428', 'local_govreporting'));
    }
    /**
     * Validate submitted form values.
     *
     * @param array $data Data.
     * @param array $files Files.
     * @return array
     */
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        if (($data['mode'] ?? '') === 'test' && empty($data['officialtest'])) {
            $errors['officialtest'] = get_string('text_f279df6b6bd4', 'local_govreporting');
        }
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', trim($data['issuer'] ?? ''))) {
            $errors['issuer'] = get_string('text_864b5228f94f', 'local_govreporting');
        }
        return $errors;
    }
}
$form = new local_govreporting_btw_certificate_form($url);
if ($form->is_cancelled()) {
    redirect($back);
}
if ($data = $form->get_data()) {
    require_sesskey();
    $provider = \local_govreporting\provider_manager::get($data->providerid);
    if (!$provider) {
        throw new invalid_parameter_exception(get_string('text_9c8378446a08', 'local_govreporting'));
    }
    $owner = \local_govreporting\provider_manager::credential_owner($provider);
    if (!$owner || $owner->id !== $provider->id) {
        throw new invalid_parameter_exception(get_string('text_c5d087541f0b', 'local_govreporting'));
    }
    if (!in_array($data->mode, ['test', 'production'], true)) {
        throw new invalid_parameter_exception(get_string('text_eb7f65489c24', 'local_govreporting'));
    }
    $files = get_file_storage()->get_area_files(context_user::instance($USER->id)->id, 'user', 'draft', $data->pfx, 'id', false);
    $file = reset($files);
    $certs = [];
    if (!$file || !openssl_pkcs12_read($file->get_content(), $certs, $data->pfxpassword) || empty($certs['pkey'])) {
        \core\notification::error(get_string('text_6e563e0f7dc7', 'local_govreporting'));
    } else {
        $signature = '';
        if (!openssl_sign(get_string('text_b6fb00b7c1e5', 'local_govreporting'), $signature, $certs['pkey'], OPENSSL_ALGO_SHA256)) {
            throw new invalid_parameter_exception(get_string('text_cfffdad223d5', 'local_govreporting'));
        }
        $prefix = \local_govreporting\provider_manager::prefix($provider, $data->mode === 'test');
        set_config($prefix . 'credentialid', trim($data->issuer), 'local_govreporting');
        set_config($prefix . 'privatekey', $certs['pkey'], 'local_govreporting');
        $file->delete();
        unset($certs, $signature);
        redirect($back, get_string('text_50666f28aa9b', 'local_govreporting'));
    }
}
echo $OUTPUT->header();
echo html_writer::div(
    html_writer::link(
        new moodle_url(
            '/admin/category.php',
            ['category' => 'local_govreporting_settings']
        ),
        get_string(
            'text_77fd1c923852',
            'local_govreporting'
        ),
        ['class' => 'btn btn-outline-secondary mb-3']
    ),
    'tpr-report-return'
);
if ($provider) {
    $form->set_data((object)['providerid' => $provider->id, 'mode' => 'test']);
}
echo html_writer::tag('p', get_string('text_654e8e8e3598', 'local_govreporting'));
echo html_writer::tag('p', get_string('text_80658bf33e49', 'local_govreporting'));
echo html_writer::tag('p', get_string('text_083fd0a955b6', 'local_govreporting'));
$form->display();
echo $OUTPUT->footer();
