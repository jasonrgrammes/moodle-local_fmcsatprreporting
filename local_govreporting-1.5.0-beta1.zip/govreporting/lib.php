<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR lib integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
/**
 * Add the reporting link for authorized staff.
 * @param global_navigation $navigation Moodle navigation.
 */
function local_govreporting_extend_navigation(global_navigation $navigation) {
    if (
        isloggedin() && !isguestuser() &&
            has_capability('local/govreporting:viewreport', context_system::instance())
    ) {
        $navigation->add(
            get_string('pluginname', 'local_govreporting'),
            new moodle_url('/local/govreporting/report.php'),
            navigation_node::TYPE_CUSTOM,
            null,
            'govreporting',
            new pix_icon('i/report', '')
        );
    }
}
/**
 * Create missing fields only; never overwrite another site's existing profile fields.
 * Identity fields are not displayed publicly or added to signup forms.
 */
function local_govreporting_install_profile_fields() {
    global $DB;
    $category = $DB->get_record('user_info_category', ['name' => get_string('text_c38510b0ef25', 'local_govreporting')]);
    if (!$category) {
        $category = (object)['name' => get_string('text_c38510b0ef25', 'local_govreporting'), 'sortorder' =>
            1 + (int)$DB->get_field_sql('SELECT MAX(sortorder) FROM {user_info_category}')];
        $category->id = $DB->insert_record('user_info_category', $category);
    }
    $fields = [
        'DL' => [get_string('text_83b4adee0a7f', 'local_govreporting'), 'text', ''],
        'DOB_Month' => [get_string('text_b6633b9034d4', 'local_govreporting'), 'text', ''],
        'DOB_Day' => [get_string('text_92c9a8b3cac2', 'local_govreporting'), 'text', ''],
        'DOB_Year' => [get_string('text_984adebd553e', 'local_govreporting'), 'text', ''],
        'State' => [get_string('text_691706123cca', 'local_govreporting'), 'text', ''],
        'training_completion' => [get_string('text_663b036254a4', 'local_govreporting'), 'datetime', ''],
        'theory_score' => [get_string('text_f85363553270', 'local_govreporting'), 'text', ''],
        'Group' => ['Group', 'menu', 'Please Select Cohort'],
        'CDLProgram' => [get_string(
            'text_60727c429597',
            'local_govreporting'
        ),
             'menu',
             "Please select\nClass A\nClass B\nHazardous Materials\nPassenger\nSchool Bus\nRestricted Class A"],

        'BTW_Range_Clock_Hours' => [get_string('text_ddb326ab3a3c', 'local_govreporting'), 'text', ''],
        'BTW_Road_Clock_Hours' => [get_string('text_296c7d168f81', 'local_govreporting'), 'text', ''],
        'Training_Location' => [get_string(
            'text_5036ddd25e82',
            'local_govreporting'
        ),
             'menu',
             get_string(
                 'text_cdc79f61df92',
                 'local_govreporting'
             )],

        'Training_State' => [get_string('text_3a11922c5d25', 'local_govreporting'), 'text', ''],
        'Training_Zip' => [get_string('text_be2a606b04a7', 'local_govreporting'), 'text', ''],
        'Training_Street' => [get_string('text_656c58832fc4', 'local_govreporting'), 'text', ''],
        'Training_City' => [get_string('text_e1784fab6ad0', 'local_govreporting'), 'text', ''],
    ];
    foreach ($fields as $shortname => [$name, $datatype, $options]) {
        if ($DB->record_exists('user_info_field', ['shortname' => $shortname])) {
            continue;
        }
        $field = (object)['shortname' => $shortname, 'name' => $name, 'datatype' => $datatype,
            'description' => '', 'descriptionformat' => FORMAT_HTML, 'categoryid' => $category->id,
            'sortorder' => 1 + $DB->count_records('user_info_field', ['categoryid' => $category->id]),
            'required' => 0, 'locked' => 0, 'visible' => 0, 'forceunique' => 0, 'signup' => 0,
            'defaultdata' => '', 'defaultdataformat' => FORMAT_PLAIN,
            'param1' => $datatype === 'menu' ? $options : ($datatype === 'datetime' ? '1900' : '30'),
            'param2' => $datatype === 'datetime' ? (string)((int)date('Y') + 10) : '2048',
            'param3' => '0', 'param4' => '', 'param5' => ''];
        $DB->insert_record('user_info_field', $field);
    }
}
