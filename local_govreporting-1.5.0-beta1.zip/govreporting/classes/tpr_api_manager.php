<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes tpr api manager integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting;

defined('MOODLE_INTERNAL') || die();

// Include the Moodle curl library.
require_once($CFG->libdir . '/filelib.php');

/**
 * Class tpr_api_manager
 *
 * This class handles FMCSA TPR API interactions for the Government Reporting plugin.
 */
class tpr_api_manager {
        /**
         * Validate the payload before creating a pending outbound attempt.
         *
         * @param \stdClass $student Student reporting data.
         * @param \stdClass|null $bundle Selected reporting curriculum.
         */
    public function validate_training_data($student, $bundle = null) {
        $this->prepare_training_data($student, $bundle);
    }

    /**
     * Check whether issuer and signing key have been configured.
     *
     * @return bool
     */
    public function credentials_configured() {
        return !empty($this->credentialid) && !empty($this->privatekey);
    }
    /**
     * Determine whether the selected credentials use the test configuration.
     *
     * @return bool
     */
    public function is_testmode() {
        return (bool)$this->testmode;
    }
    /**
     * Normalise full state names without guessing from their first letters.
     */
    public function normalise_state($state) {
        $state = preg_replace('/^US-/i', '', trim($state));
        $abbr = strtoupper($this->map_state_to_abbreviation($state, true));
        $valid = explode(
            ' ',
            'AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC N' .
            'D OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY DC PR VI GU AS MP'
        );
        return in_array($abbr, $valid, true) ? $abbr : '';
    }
    /** @var mixed Internal reporting state. */
    private $provider;

    /**
     * @var string FMCSA TPR API endpoint URL
     */
    private $apiurl;

    /**
     * @var string Credential ID (issuer)
     */
    private $credentialid;

    /**
     * @var string Private key for signing JWT tokens
     */
    private $privatekey;

    /**
     * @var bool Whether we're in test mode or not
     */
    private $testmode;

    /**
     * Constructor.
     */
    public function __construct($profile = 'theory', $providerid = 0) {
        global $CFG;

        $provider = $providerid ? provider_manager::get($providerid)
            : provider_manager::default_provider($profile === 'btw' ? 'Range' : 'Theory');
        if ($provider && !provider_manager::credential_owner($provider)) {
            $provider = null;
        }
        if ($provider) {
            $this->provider = $provider;
            $this->testmode = provider_manager::is_testmode($provider);
            $this->apiurl = 'https://tpr.fmcsa.dot.gov/api/Training/Add';
            $prefix = provider_manager::prefix($provider);
            $this->credentialid = get_config('local_govreporting', $prefix . 'credentialid');
            $this->privatekey = get_config('local_govreporting', $prefix . 'privatekey');
            return;
        }
        $this->apiurl = 'https://tpr.fmcsa.dot.gov/api/Training/Add';
        $this->testmode = true;
    }

    /**
     * Generate JWT token for authentication
     *
     * @return string The JWT token
     * @throws \Exception If the token generation fails
     */
    private function generate_token() {
        // Check that we have credentials configured.
        if (empty($this->credentialid)) {
            throw new \Exception(get_string('text_c4a1be8f6073', 'local_govreporting'));
        }

        if (empty($this->privatekey)) {
            throw new \Exception(get_string('text_e4f91d22a3cf', 'local_govreporting'));
        }

        // Calculate not before (current time) and expiration (current time + 10 minutes).
        $now = time();
        $exp = $now + 600; // 10 minutes

        // Create token payload.
        $payload = [
            'nbf' => $now,
            'exp' => $exp,
            'iss' => $this->credentialid,
        ];

        // Sign the token with RS256 algorithm.
        return $this->sign_jwt($payload);
    }

    /**
     * Sign a JWT payload with RS256 algorithm
     *
     * @param array $payload The payload to sign
     * @return string The JWT token
     * @throws \Exception If the signing fails
     */
    private function sign_jwt($payload) {
        // Create JWT header.
        $header = [
            'alg' => 'RS256',
            'typ' => 'JWT',
        ];

        // Encode header and payload.
        $headerencoded = $this->base64url_encode(json_encode($header));
        $payloadencoded = $this->base64url_encode(json_encode($payload));
        $data = $headerencoded . '.' . $payloadencoded;

        // Ensure private key is in the correct format.
        $privatekey = $this->privatekey;

        // If the private key doesn't contain BEGIN/END markers, add them.
        if (strpos($privatekey, '-----BEGIN') === false) {
            $privatekey = get_string('text_f908016d4cb9', 'local_govreporting') . '
' . $privatekey . '
' . get_string('text_52a46ee6d66e', 'local_govreporting');
        }

        // Sign the data.
        $signature = '';
        if (!openssl_sign($data, $signature, $privatekey, OPENSSL_ALGO_SHA256)) {
            $error = openssl_error_string();
            throw new \Exception(get_string(
                'text_76b43e2d0a72',
                'local_govreporting'
            ) .
                 ' ' .
                 ($error ? $error : get_string(
                     'text_10430ff704a3',
                     'local_govreporting'
                 )));
        }

        // Encode signature and create token.
        $signatureencoded = $this->base64url_encode($signature);
        return $headerencoded . '.' . $payloadencoded . '.' . $signatureencoded;
    }

    /**
     * Base64URL encoding helper function
     *
     * @param string $data The data to encode
     * @return string The base64url encoded string
     */
    private function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Submit student training data to FMCSA TPR
     *
     * @param \stdClass $student The student data object
     * @param \stdClass|null $bundle The bundle object (optional, for bundle submissions)
     * @param string|null $classendorsementcode Override class/endorsement code (optional)
     * @return array ['success' => bool, 'message' => string, 'code' => int]
     */
    public function submit_training_data($student, $bundle = null, $classendorsementcode = null) {
        global $CFG;

        try {
            // Check if API settings are configured.
            if (empty($this->credentialid) || empty($this->privatekey)) {
                return [
                    'success' => false,
                    'message' => get_string('text_25cebe11e783', 'local_govreporting'),
                    'code' => 0,
                ];
            }

            // Verify the student object has required fields.
            if (empty($student) || !is_object($student)) {
                return [
                    'success' => false,
                    'message' => get_string('text_5e9420bddd9f', 'local_govreporting'),
                    'code' => 0,
                ];
            }

            // Check required fields.
            if (empty($student->firstname) || empty($student->lastname)) {
                return [
                    'success' => false,
                    'message' => get_string('text_7518b20eafe6', 'local_govreporting'),
                    'code' => 0,
                ];
            }

            // Generate JWT token.
            $token = $this->generate_token();

            // Prepare data for submission.
            $data = $this->prepare_training_data($student, $bundle, $classendorsementcode);

            // Set up the curl request - using Moodle's curl class.
            $curl = new \curl();
            $curl->setHeader('Content-Type: application/json');
            $curl->setHeader('Authorization: Bearer ' . $token);

            // Make the API call.
            $jsondata = json_encode($data);
            if ($jsondata === false) {
                return [
                    'success' => false,
                    'message' => get_string('text_dc6c89e03562', 'local_govreporting') . ' ' . json_last_error_msg(),
                    'code' => 0,
                ];
            }

            $curl->setopt(['CURLOPT_CONNECTTIMEOUT' => 15, 'CURLOPT_TIMEOUT' => 60]);
            $response = $curl->post($this->apiurl, $jsondata);
            $info = $curl->info;

            // Process the response.
            $result = [
                'success' => false,
                'message' => get_string('text_e5fd9aa24c94', 'local_govreporting'),
                'code' => 0,
            ];

            if ($info && isset($info['http_code'])) {
                $result['code'] = $info['http_code'];

                if ($info['http_code'] == 201) { // FMCSA TPR uses 201 for successful creation.
                    $result['success'] = true;
                    $result['message'] = get_string('text_bedfe9f17219', 'local_govreporting');
                } else {
                    // Try to decode the error message if available.
                    $error = json_decode($response);
                    if ($error && isset($error->detail)) {
                        $result['message'] = $error->detail;
                    } else {
                        $result['message'] = get_string(
                            'text_b53b4e99eae3',
                            'local_govreporting'
                        ) .
                             ' ' .
                             $info['http_code'] .
                             ' - ' .
                             $response;
                    }
                }
            } else {
                $result['message'] = get_string('text_8c51ee1cedb4', 'local_govreporting');
            }

            return $result;
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage(),
                'code' => 0,
            ];
        }
    }

    /**
     * Prepare student data for FMCSA TPR API submission
     *
     * @param \stdClass $student The student object
     * @param \stdClass|null $bundle The bundle object (optional, for bundle submissions)
     * @param string|null $classendorsementcode Override class/endorsement code (optional)
     * @return array The formatted data for the FMCSA TPR API
     */
    private function prepare_training_data($student, $bundle = null, $classendorsementcode = null) {
        $group = data_manager::require_student_group($student->id);
        if (isset($student->btw_payload)) {
            $payload = $student->btw_payload;
            foreach ($payload['TrainingElements'] as &$element) {
                $element['InternalId'] = $group;
            }
            unset($element);
            return $payload;
        }
        // Format date fields
        // DOB should already be in YYYY-MM-DD format from data_manager, but validate it.
        $dob = '';
        if (!empty($student->date_of_birth)) {
            // If already in YYYY-MM-DD format, use it directly.
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $student->date_of_birth)) {
                $dob = $student->date_of_birth;
            } else {
                // Try to parse and format.
                $parsed = strtotime($student->date_of_birth);
                if ($parsed !== false) {
                    $dob = date('Y-m-d', $parsed);
                }
            }
        }

        $completion = $student->training_completion ?? '';
        $timestamp = ctype_digit((string)$completion) ? (int)$completion : strtotime((string)$completion);
        if (!$timestamp || $timestamp > time()) {
            throw new \invalid_parameter_exception(get_string('text_60e1c886a00e', 'local_govreporting'));
        }
        $trainingcompletion = date('Y-m-d', $timestamp);

        // Determine class/endorsement application type.
        $applicationtype = 'New'; // Default.
        if (!empty($student->application_type)) {
            $applicationtype = $student->application_type;
        }

        // Ensure we have a valid provider location ID.
        $providerlocationid = $this->provider->locationid ?? '';
        if (empty($providerlocationid)) {
            throw new \invalid_parameter_exception(get_string('text_3fd26578fc19', 'local_govreporting'));
        }

        // Determine the class/endorsement code to use.
        $endorsementcode = 'A'; // Default.
        if ($classendorsementcode !== null) {
            $endorsementcode = $classendorsementcode;
        } else if ($bundle !== null && isset($bundle->classendorsementcode)) {
            $endorsementcode = $bundle->classendorsementcode;
        }

        // Format training elements (theory, range, public road).
        $trainingelements = [];

        // Add theory training element.
        if (isset($student->theory_score) || isset($student->average_score)) {
            // Get score - prefer theory_score, fallback to average_score.
            $rawscore = null;
            if (!empty($student->theory_score)) {
                $rawscore = $student->theory_score;
            } else if (!empty($student->average_score)) {
                $rawscore = $student->average_score;
            }

            // Only proceed if we have a valid score.
            if ($rawscore !== null && $rawscore !== '') {
                // Convert to numeric and round to integer.
                if (!is_numeric($rawscore) || (float)$rawscore < 80 || (float)$rawscore > 100) {
                    throw new \invalid_parameter_exception(get_string('text_67d22f59ffd1', 'local_govreporting'));
                }
                $score = (float)$rawscore;

                // Validate score is a number.
                if (is_numeric($score) && $score > 0) {
                    // Round to nearest integer.
                    $score = round($score);

                    // FMCSA TPR requires scores to be between 80 and 100 inclusive
                    // Clamp to valid range (80-100) as required by FMCSA TPR API.
                    $score = intval($score);

                    // Ensure score is an integer (FMCSA TPR API requirement).
                    $score = (int)$score;

                    // Get Group from profile for Internal ID
                    // Group was validated against the current saved student profile above.
                    $internalid = $group;

                    $trainingelements[] = [
                        'TrainingType' => 'Theory',
                        'CompletionDate' => $trainingcompletion,
                        'TrainingMethod' => 'Online',
                        'Score' => $score, // Integer between 80-100.
                        'InternalId' => $internalid,
                    ];
                }
            }
        }

        $state = $this->normalise_state($student->state ?? '');
        $driverlicense = trim($student->driver_license ?? '');
        if (
            $state === '' || $driverlicense === '' ||
                !preg_match('/^(\\d{4})-(\\d{2})-(\\d{2})$/', $dob, $parts) ||
                !checkdate((int)$parts[2], (int)$parts[3], (int)$parts[1])
        ) {
            throw new \invalid_parameter_exception(get_string('text_656b5e2718ab', 'local_govreporting'));
        }
        $state = 'US-' . $state;

        // Build the data array in FMCSA TPR format.
        $data = [
            'Number' => $driverlicense,
            'State' => $state,
            'FirstName' => $student->firstname,
            'LastName' => $student->lastname,
            'DateOfBirth' => $dob,
            'ClassEndorsementCode' => $endorsementcode,
            'ProviderLocationId' => $providerlocationid,
            'TrainingElements' => $trainingelements,
        ];

        // ApplicationType is ONLY required for Class A and Class B (not for H, P, S).
        if ($endorsementcode === 'A' || $endorsementcode === 'B') {
            $data['ApplicationType'] = $applicationtype;
        }

        return $data;
    }

    /**
     * Map full state name to 2-letter abbreviation
     *
     * @param string $state State name or abbreviation
     * @return string 2-letter state abbreviation
     */
    private function map_state_to_abbreviation($state, $strict = false) {
        $state = trim($state);

        // If already a 2-letter code, return it.
        if (strlen($state) == 2 && ctype_alpha($state)) {
            return strtoupper($state);
        }

        // Map full state names to abbreviations.
        $statemap = [
            'alabama' => 'AL',
            'alaska' => 'AK',
            'arizona' => 'AZ',
            'arkansas' => 'AR',
            'california' => 'CA',
            'colorado' => 'CO',
            'connecticut' => 'CT',
            'delaware' => 'DE',
            'florida' => 'FL',
            'georgia' => 'GA',
            'hawaii' => 'HI',
            'idaho' => 'ID',
            'illinois' => 'IL',
            'indiana' => 'IN',
            'iowa' => 'IA',
            'kansas' => 'KS',
            'kentucky' => 'KY',
            'louisiana' => 'LA',
            'maine' => 'ME',
            'maryland' => 'MD',
            'massachusetts' => 'MA',
            'michigan' => 'MI',
            'minnesota' => 'MN',
            'mississippi' => 'MS',
            'missouri' => 'MO',
            'montana' => 'MT',
            'nebraska' => 'NE',
            'nevada' => 'NV',
            get_string('text_0a92e9e0dd0b', 'local_govreporting') => 'NH',
            get_string('text_836490826951', 'local_govreporting') => 'NJ',
            get_string('text_a91fef9e6c45', 'local_govreporting') => 'NM',
            get_string('text_dddd9606dd43', 'local_govreporting') => 'NY',
            get_string('text_9da9fe9ec69d', 'local_govreporting') => 'NC',
            get_string('text_6e0bd61eb435', 'local_govreporting') => 'ND',
            'ohio' => 'OH',
            'oklahoma' => 'OK',
            'oregon' => 'OR',
            'pennsylvania' => 'PA',
            get_string('text_fd1dca9e1aa8', 'local_govreporting') => 'RI',
            get_string('text_42e4fefb0994', 'local_govreporting') => 'SC',
            get_string('text_76b559c2d6d1', 'local_govreporting') => 'SD',
            'tennessee' => 'TN',
            'texas' => 'TX',
            'utah' => 'UT',
            'vermont' => 'VT',
            'virginia' => 'VA',
            'washington' => 'WA',
            get_string('text_0cab3c410d5f', 'local_govreporting') => 'WV',
            'wisconsin' => 'WI',
            'wyoming' => 'WY',
            get_string('text_62e4b481d0cb', 'local_govreporting') => 'DC',
            get_string('text_2ed3972fccfc', 'local_govreporting') => 'DC',
        ];

        $statelower = strtolower($state);

        // Check for exact match.
        if (isset($statemap[$statelower])) {
            return $statemap[$statelower];
        }
        if ($strict) {
            return '';
        }

        // Check for partial matches (e.g., "Mississippi" might be stored as "Mississippi").
        foreach ($statemap as $key => $abbr) {
            if (strpos($statelower, $key) !== false || strpos($key, $statelower) !== false) {
                return $abbr;
            }
        }

        // If no match found, try to extract first 2 letters.
        $state = preg_replace('/[^A-Za-z]/', '', $state);
        if (strlen($state) >= 2) {
            return strtoupper(substr($state, 0, 2));
        }

        return 'XX'; // Default.
    }
}
