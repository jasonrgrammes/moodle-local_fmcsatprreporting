<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes output report page integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting\output;


use renderable;
use templatable;
use renderer_base;
use stdClass;
use paging_bar;

/**
 * Class report_page
 *
 * @package     local_govreporting\output
 */
class report_page implements renderable, templatable {
    /**
     * @var array List of eligible students for the current page
     */
    protected $students;

    /**
     * @var int Total number of eligible students (across all pages)
     */
    protected $totalcount;

    /**
     * @var paging_bar The pagination bar
     */
    protected $pagingbar;

    /**
     * @var string Current active tab
     */
    protected $activetab;

    /**
     * @var array List of bundles
     */
    protected $bundles;

    /**
     * @var int Selected bundle ID
     */
    protected $selectedbundleid;

    /** @var mixed Internal reporting state. */
    protected $initials;

    /**
     * Constructor.
     *
     * @param array $students The list of eligible students for current page
     * @param int $totalcount Total number of eligible students
     * @param paging_bar $pagingbar The pagination bar
     * @param string $activetab The active tab (eligible or submitted)
     * @param array $bundles List of bundles
     * @param int $selectedbundleid Selected bundle ID
     */
    public function __construct(
        $students,
        $totalcount,
        $pagingbar,
        $activetab = 'eligible',
        $bundles = [],
        $selectedbundleid = 0,
        $initials = []
    ) {
        $this->initials = $initials;
        $this->students = $students;
        $this->totalcount = $totalcount;
        $this->pagingbar = $pagingbar;
        $this->activetab = $activetab;
        $this->bundles = $bundles;
        $this->selectedbundleid = $selectedbundleid;
    }

    /**
     * Export data for the template.
     *
     * @param renderer_base $output The renderer
     * @return stdClass Data for the template
     */
    public function export_for_template(renderer_base $output) {
        global $PAGE, $DB;

        $data = new stdClass();
        $data->title = get_string('report_title', 'local_govreporting');
        $data->can_configure = is_siteadmin();
        $data->settings_url = (new \moodle_url('/admin/category.php', ['category' => 'local_govreporting_settings']))->out(false);

        // Tab information.
        $data->tab_eligible_active = ($this->activetab === 'eligible');
        $data->can_archive = is_siteadmin();
        $data->is_eligible_tab = $this->activetab === 'eligible';
        $data->is_archived_tab = $this->activetab === 'archived';
        $data->tab_archived_active = $data->is_archived_tab;
        $data->archive_action_url = (new \moodle_url('/local/govreporting/archive.php'))->out(false);
        $data->sesskey = sesskey();
        $data->tab_archived_url = (new \moodle_url(
            '/local/govreporting/report.php',
            array_merge(
                $this->initials,
                ['tab' => 'archived',
                'category' => $this->selectedbundleid]
            )
        ))->out(false);
        $data->tab_submitted_active = ($this->activetab === 'submitted');
        $data->tab_eligible_url = (new \moodle_url(
            '/local/govreporting/report.php',
            ['tab' => 'eligible',
             'firstinitial' => $this->initials['firstinitial'] ?? '',
             'lastinitial' => $this->initials['lastinitial'] ?? '',
             'category' => $this->selectedbundleid,
            'group' => $this->initials['group'] ?? '']
        ))->out(false);
        $data->tab_submitted_url = (new \moodle_url(
            '/local/govreporting/report.php',
            ['tab' => 'submitted',
             'firstinitial' => $this->initials['firstinitial'] ?? '',
             'lastinitial' => $this->initials['lastinitial'] ?? '',
             'category' => $this->selectedbundleid,
            'group' => $this->initials['group'] ?? '']
        ))->out(false);

        // Description and messages based on active tab.
        if ($this->activetab === 'submitted') {
            $data->description = get_string('text_e81e15339d6e', 'local_govreporting');
            $data->no_students_message = get_string('no_submitted_students', 'local_govreporting');
            $data->is_submitted_tab = true;
        } else {
            $data->description = get_string('text_a8a70d4a60aa', 'local_govreporting');
            $data->no_students_message = get_string('no_eligible_students', 'local_govreporting');
            $data->is_submitted_tab = false;
        }

        if ($data->is_archived_tab) {
            $data->description = get_string('text_d6fbcfc31204', 'local_govreporting');
            $data->no_students_message = get_string('text_0eee3e3b29f5', 'local_govreporting');
        }
        $data->has_students = !empty($this->students);

        // Add pagination information.
        $data->has_pagination = ($this->totalcount > 0);
        $data->total_students = $this->totalcount;
        if ($this->pagingbar) {
            $data->pagination = $output->render($this->pagingbar);
        }

        // Add bundle filter data.
        $data->bundles = [];
        foreach ($this->bundles as $bundle) {
            $data->bundles[] = [
                'id' => $bundle->id,
                'name' => $bundle->name,
                'selected' => ($bundle->id == $this->selectedbundleid),
            ];
        }

        $data->has_bundles = !empty($data->bundles);
        $data->has_filters = true;
        $data->firstinitial = $this->initials['firstinitial'] ?? '';
        $data->lastinitial = $this->initials['lastinitial'] ?? '';
        $data->groups = [];
        $groupfield = $DB->get_record('user_info_field', ['shortname' => 'Group']);
        if ($groupfield) {
            foreach (array_unique(preg_split('/\r\n|\r|\n/', $groupfield->param1)) as $group) {
                $group = trim($group);
                if ($group === '' || preg_match('/^please select/i', $group)) {
                    continue;
                }
                $data->groups[] = ['value' => $group, 'name' => $group,
                    'selected' => ($this->initials['group'] ?? '') === $group];
            }
        }
        $data->initialrows = [];
        foreach (['firstinitial' => get_string('firstname'), 'lastinitial' => get_string('lastname')] as $key => $label) {
            $row = ['key' => $key, 'label' => $label, 'all' => [], 'letters' => []];
            foreach (array_merge([''], range('A', 'Z')) as $letter) {
                $params = array_merge($this->initials, [
                    'tab' => $this->activetab, 'category' => $this->selectedbundleid, $key => $letter,
                ]);
                $item = [
                    'text' => $letter === '' ? get_string('all') : $letter,
                    'url' => (new \moodle_url('/local/govreporting/report.php', $params))->out(false),
                    'active' => ($this->initials[$key] ?? '') === $letter,
                ];
                if ($letter === '') {
                    $row['all'][] = $item;
                } else {
                    $row['letters'][] = $item;
                }
            }
            $data->initialrows[] = $row;
        }
        $data->selected_bundle = $this->selectedbundleid;
        $data->current_tab = $this->activetab;

        $data->training_entry_url = (new \moodle_url('/local/govreporting/btw.php'))->out(false);
        $btwmanager = new \local_govreporting\btw_manager();
        $btwconfigured = \local_govreporting\provider_manager::configured(
            \local_govreporting\provider_manager::default_provider(
                'Range'
            )
        );
        $data->btw_needs_configuration = is_siteadmin() && !$btwconfigured;
        $data->btw_settings_url = (new \moodle_url('/admin/settings.php', ['section' => 'local_govreporting_config']))->out(false);
        $data->students = [];

        foreach ($this->students as $student) {
            $trainingprofile = $btwmanager->profile($student->id);
            $studentdata = new stdClass();
            $studentdata->id = $student->id;
            $studentdata->firstname = $student->firstname;
            $studentdata->lastname = $student->lastname;
            $studentdata->fullname = $student->firstname . ' ' . $student->lastname;
            $studentdata->can_edit_profile = is_siteadmin() || has_capability('moodle/user:update', \context_system::instance());
            $studentdata->edit_profile_url = (new \moodle_url(
                '/user/editadvanced.php',
                ['id' => $student->id,
                'course' => SITEID]
            ))->out(false);
            $studentdata->driver_license = !empty(
                $student->driver_license
            ) ?
                 $student->driver_license :
                 (
                (
                $trainingprofile['DL'] ?? '') ?
                 :
                 'N/A');
            $studentdata->date_of_birth = !empty($student->date_of_birth) ? $student->date_of_birth :
                (!empty($trainingprofile['DOB_Year']) ? (($trainingprofile['DOB_Month'] ?? '') .
                     '/' .
                     ($trainingprofile['DOB_Day'] ?? '') .
                     '/' .
                     $trainingprofile['DOB_Year']) : 'N/A');
            $studentdata->state = !empty($student->state) ? $student->state : (($trainingprofile['State'] ?? '') ?: 'N/A');
            $studentdata->training_completion = !empty($student->training_completion) ? $student->training_completion :
                (!empty($trainingprofile['training_completion']) ? userdate(
                    (int)$trainingprofile['training_completion'],
                    get_string(
                        'strftimedate',
                        'langconfig'
                    )
                ) : 'N/A');
            $studentdata->theory_score = !empty($student->average_score) ? number_format($student->average_score, 1) . '%' : 'N/A';

            $studentgroup = $student->group ?? '';
            if ($studentgroup === '' && $groupfield) {
                $studentgroup = $DB->get_field('user_info_data', 'data', ['fieldid' => $groupfield->id, 'userid' => $student->id]);
            }
            $studentdata->group_valid = \local_govreporting\data_manager::valid_group($studentgroup);
            $studentdata->group_name = $studentdata->group_valid ? $studentgroup : get_string(
                'text_b781e616a946',
                'local_govreporting'
            );
            $studentdata->group_required = $data->is_eligible_tab && !$studentdata->group_valid;

            // Hours entry stays available after theory acceptance; it does not submit training.
            $studentdata->can_enter_btw_hours = $this->activetab !== 'archived' &&
                has_capability('local/govreporting:viewreport', \context_system::instance());
            $studentdata->btw_range_edit_url = (new \moodle_url('/local/govreporting/btw.php', [
                'userid' => $student->id, 'component' => 'Range', 'returntab' => $this->activetab,
            ]))->out(false) . '#id_BTW_Range_Clock_Hours';
            $studentdata->btw_road_edit_url = (new \moodle_url('/local/govreporting/btw.php', [
                'userid' => $student->id, 'component' => 'PublicRoad', 'returntab' => $this->activetab,
            ]))->out(false) . '#id_BTW_Road_Clock_Hours';

            $studentdata->training_edit_url = (new \moodle_url(
                '/local/govreporting/btw.php',
                ['userid' => $student->id]
            ))->out(false);
            $studentdata->btw_components = $btwmanager->report_components(
                $student->id,
                $this->activetab,
                ['bundleid' => $this->selectedbundleid],
                $trainingprofile
            );
            foreach ($studentdata->btw_components as &$component) {
                $component['can_review'] = is_siteadmin() &&
                     $studentdata->group_valid &&
                     $component['ready'] &&
                     $component['configured'];
                $component['review_url'] = (new \moodle_url('/local/govreporting/btw.php', [
                    'userid' => $student->id, 'action' => 'review', 'component' => $component['component']]))->out(false);
            }
            unset($component);
            $studentdata->btw_history = [];
            foreach ($DB->get_records('local_govreporting_btw', ['userid' => $student->id], 'timecreated DESC,id DESC') as $entry) {
                if ($this->activetab !== 'submitted' || !in_array($entry->component, ['Range', 'PublicRoad'], true)) {
                    continue;
                }
                $snapshot = json_decode($entry->payload, true) ?: [];
                $snapshot = $snapshot['request'] ?? $snapshot;
                $element = $snapshot['TrainingElements'][0] ?? [];
                $studentdata->btw_history[] = ['component' => $entry->component === 'Range' ? 'Range' : get_string(
                    'text_7c7448eeb4d3',
                    'local_govreporting'
                ),

                    'category' => $entry->categorycode,
                         'status' => $entry->status === 'submitted' ? get_string(
                             'text_ad4eb1aafda6',
                             'local_govreporting'
                         ) : $entry->status,

                    'hours' => $element['Hours'] ?? '', 'completion' => $element['CompletionDate'] ?? '',
                    'date' => userdate($entry->timecreated)];
            }
            $studentdata->has_btw_training = !empty($studentdata->btw_components) || !empty($studentdata->btw_history);
            // Format courses and scores.
            $studentdata->courses = [];
            foreach ($student->courses as $course) {
                $coursedata = new stdClass();
                $coursedata->name = $course->fullname;
                $coursedata->score = number_format($course->score, 1) . '%';
                $studentdata->courses[] = $coursedata;
            }

            // Format course list as a string for display.
            $coursestrings = array_map(function ($course) {
                return $course->name . ' (' . $course->score . ')';
            }, $studentdata->courses);
            $studentdata->course_list = implode(', ', $coursestrings);
            $studentdata->course_count = count($studentdata->courses);

            // Add submission information if in submitted tab.
            if ($this->activetab === 'submitted') {
                $studentdata->submission_date = !empty($student->submission_date_formatted) ?
                    $student->submission_date_formatted : 'N/A';
                $studentdata->last_modified = !empty($student->last_modified_formatted) ?
                    $student->last_modified_formatted : 'N/A';
                $studentdata->attempt = !empty($student->attempt) ? $student->attempt : '1';
            }

            // Each action identifies one reporting bundle, never an implicit first match.
            $studentdata->reporting_options = [];
            foreach ($student->completed_bundles ?? [] as $completed) {
                $bundle = $completed['bundle'];
                $scores = array_column($completed['courses'], 'score');
                $studentdata->reporting_options[] = [
                    'bundleid' => $bundle->id,
                    'name' => $bundle->name,
                    'category' => $bundle->classendorsementcode,
                    'score' => $scores ? number_format(array_sum($scores) / count($scores), 1) : '',
                ];
            }
            $studentdata->submission_history = [];
            foreach ($student->submissions ?? [] as $submission) {
                $studentdata->submission_history[] = [
                    'category' => ['A' => get_string(
                        'text_65ea6ad132c8',
                        'local_govreporting'
                    ),
                         'B' => get_string(
                             'text_78fcc50b6093',
                             'local_govreporting'
                         ),
                         'H' => get_string(
                             'text_d6d6c26958c0',
                             'local_govreporting'
                         ),
                         'P' => 'Passenger',
                         'S' => get_string(
                             'text_bdbf8ae5c96f',
                             'local_govreporting'
                         )][$submission->classendorsementcode] ?? $submission->classendorsementcode,

                    'reference' => $submission->bundlecourseid,
                    'date' => userdate($submission->submission_date),
                    'attempt' => $submission->attempt,
                ];
            }

            $studentdata->has_theory_history = !empty($studentdata->submission_history);
            $studentdata->archive_records = [];
            foreach ($student->archives ?? [] as $archive) {
                $studentdata->archive_records[] = [
                    'archiveid' => $archive->archiveid,
                    'category' => ['A' => get_string(
                        'text_65ea6ad132c8',
                        'local_govreporting'
                    ),
                         'B' => get_string(
                             'text_78fcc50b6093',
                             'local_govreporting'
                         ),
                         'H' => get_string(
                             'text_d6d6c26958c0',
                             'local_govreporting'
                         ),
                         'P' => 'Passenger',
                         'S' => get_string(
                             'text_bdbf8ae5c96f',
                             'local_govreporting'
                         )][$archive->categorycode] ?? $archive->categorycode,

                    'reason' => $archive->reason, 'date' => userdate($archive->timecreated),
                ];
            }
            // Submit button (only show in eligible tab).
            $studentdata->submit_button = get_string('submit_to_government', 'local_govreporting');

            $data->students[] = $studentdata;
        }

        return $data;
    }
}
