<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes external submit student integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting\external;



use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;
use local_govreporting\tpr_api_manager;
use local_govreporting\data_manager;

/**
 * External service for submitting student data to government database.
 *
 * @package    local_govreporting\external
 */
class submit_student extends external_api {
    /**
     * Returns description of method parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters() {
        return new external_function_parameters([
            'userid' => new external_value(PARAM_INT, get_string('text_945545faf33c', 'local_govreporting')),
            'bundleid' => new external_value(PARAM_INT, get_string('text_65803f250750', 'local_govreporting'), VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * Returns description of method result value.
     *
     * @return external_single_structure
     */
    public static function execute_returns() {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, get_string('text_5b7573ac7b69', 'local_govreporting')),
            'message' => new external_value(PARAM_TEXT, get_string('text_637841f6e1ce', 'local_govreporting')),
            'code' => new external_value(PARAM_INT, get_string('text_57b0efb967df', 'local_govreporting')),
        ]);
    }

    /**
     * Submit student data to government database via FMCSA TPR API.
     *
     * @param int $userid The user ID to submit
     * @param int $bundleid The bundle ID to submit (optional, 0 for first available bundle)
     * @return array Response data
     */
    public static function execute($userid, $bundleid = 0) {
        global $DB;

        // Parameter validation.
        $params = self::validate_parameters(self::execute_parameters(), [
            'userid' => $userid,
            'bundleid' => $bundleid,
        ]);
        $userid = $params['userid'];
        $bundleid = $params['bundleid'];

        // Security checks.
        $context = \context_system::instance();
        self::validate_context($context);
        require_capability('local/govreporting:submitdata', $context);
        if (!is_siteadmin()) {
            throw new \required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
        }

        // Serialize submissions for a student, including across different browser tabs.
        $factory = \core\lock\lock_config::get_lock_factory('local_govreporting');
        $lock = $factory->get_lock('submit-student-' . $userid, 10);
        if (!$lock) {
            return ['success' => false, 'message' => get_string('text_0a492f902def', 'local_govreporting'), 'code' => 409];
        }
        try {
            // Block before building a request or creating a failed submission record.
            if (!data_manager::valid_group(data_manager::student_group($userid))) {
                return ['success' => false, 'message' => get_string('text_1f93a97c3f1c', 'local_govreporting'), 'code' => 422];
            }
            // Get the user data.
            $datamanager = new data_manager();
            $students = $datamanager->get_eligible_students();

            $student = null;
            foreach ($students as $s) {
                if ($s->id == $userid) {
                    $student = $s;
                    break;
                }
            }

            if (!$student) {
                return [
                'success' => false,
                'message' => get_string(
                    'error_submission',
                    'local_govreporting'
                ) .
                     get_string(
                         'text_7107ed8b8109',
                         'local_govreporting'
                     ),

                'code' => 404,
                ];
            }

            // Check if student has completed bundles.
            if (empty($student->completed_bundles)) {
                return [
                'success' => false,
                'message' => get_string(
                    'error_submission',
                    'local_govreporting'
                ) .
                     get_string(
                         'text_5510953bd606',
                         'local_govreporting'
                     ),

                'code' => 404,
                ];
            }

            // Find the bundle to submit.
            $bundletosubmit = null;
            if ($bundleid !== 0) {
                // Find specific bundle.
                foreach ($student->completed_bundles as $cb) {
                    if ($cb['bundle']->id == $bundleid) {
                        $bundletosubmit = $cb;
                        break;
                    }
                }

                if (!$bundletosubmit) {
                    return [
                    'success' => false,
                    'message' => get_string(
                        'error_submission',
                        'local_govreporting'
                    ) .
                         get_string(
                             'text_748901c4829b',
                             'local_govreporting'
                         ),

                    'code' => 404,
                    ];
                }
            } else {
                // Use first available bundle.
                return ['success' => false, 'message' => get_string('text_f50226d868be', 'local_govreporting'), 'code' => 400];
            }

            $bundle = $bundletosubmit['bundle'];
            $student = clone $student;
            $scores = array_column($bundletosubmit['courses'], 'score');
            if (!$scores) {
                throw new \invalid_parameter_exception(get_string('text_dd9869797cac', 'local_govreporting'));
            }
            // Send the selected curriculum average, never a stale profile score or another endorsement's average.
            $student->average_score = array_sum($scores) / count($scores);
            $student->theory_score = $student->average_score;

            if (
                $DB->record_exists_select(
                    'local_govreporting_submissions',
                    'userid = :userid AND classendorsementcode = :code AND status IN (:pending, :unknown)',
                    ['userid' => $userid, 'code' => $bundle->classendorsementcode,
                    'pending' => 'pending',
                    'unknown' => 'unknown']
                )
            ) {
                return ['success' => false, 'message' => get_string('text_f106a9973746', 'local_govreporting'), 'code' => 409];
            }
            $preflight = new tpr_api_manager();
            if (!$preflight->credentials_configured()) {
                return ['success' => false, 'message' => get_string('credentials_required', 'local_govreporting'), 'code' => 422];
            }
            try {
                $preflight->validate_training_data($student, $bundle);
            } catch (\invalid_parameter_exception $e) {
                return ['success' => false, 'message' => $e->getMessage(), 'code' => 422];
            }
            $datamanager->record_submission($userid, 'pending', '', $bundle->id, $bundle->classendorsementcode, 0);
            // Submit to FMCSA TPR API.
            $apimanager = new tpr_api_manager();
            $result = $apimanager->submit_training_data($student, $bundle);

            // Record the submission.
            if ($result['success']) {
                $status = $apimanager->is_testmode() ? 'tested' : 'submitted';
            } else {
                $status = empty($result['code']) ? 'unknown' : 'failed';
            }
            $datamanager->record_submission(
                $userid,
                $status,
                json_encode($result),
                $bundle->id,
                $bundle->classendorsementcode,
                0  // Isstandalone = 0 (this is a bundle).
            );

            // Return the result.
            return [
            'success' => $result['success'],
            'message' => $result['success'] ?
                ($apimanager->is_testmode() ? get_string(
                    'text_803fbda0b48c',
                    'local_govreporting'
                ) : get_string(
                    'success_submission',
                    'local_govreporting'
                )) .
                     ' (' .
                     $bundle->name .
                     ')' :
                get_string('error_submission', 'local_govreporting') . ': ' . $result['message'],
            'code' => $result['code'],
            ];
        } finally {
            $lock->release();
        }
    }
}
