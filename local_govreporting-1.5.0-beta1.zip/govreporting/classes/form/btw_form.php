<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes form btw form integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting\form;
defined('MOODLE_INTERNAL') || die();
require_once($CFG->libdir . '/formslib.php');

/**
 * Btw form for FMCSA TPR workflows.
 */
class btw_form extends \moodleform {
    /**
     * Define the form controls.
     *
     * @return void
     */
    public function definition() {
        $m = $this->_form;
        $focus = ($this->_customdata['focuscomponent'] ?? '') === 'Range' ? 'BTW_Range_Clock_Hours' :
            (($this->_customdata['focuscomponent'] ?? '') === 'PublicRoad' ? 'BTW_Road_Clock_Hours' : '');
        $m->addElement('hidden', 'userid');
        $m->setType('userid', PARAM_INT);
        $m->addElement('header', 'training', get_string('text_2721f9009853', 'local_govreporting'));
        $m->addElement('static', 'note', '', get_string('text_8373255409bd', 'local_govreporting'));
        foreach ($this->_customdata['fields'] as $f) {
            if ($f->shortname === 'Training_Location') {
                $options = ['' => get_string('text_7829c2bdd074', 'local_govreporting')];
                foreach (\local_govreporting\provider_manager::all() as $provider) {
                    if (array_intersect(['Range', 'PublicRoad'], explode(',', $provider->components))) {
                        $options[$provider->name] = $provider->name;
                    }
                }
                $m->addElement('select', 'Training_Location', get_string('text_870869488ad1', 'local_govreporting'), $options);
                $m->setType('Training_Location', PARAM_TEXT);
            } else if ($f->datatype === 'menu') {
                $options = ['' => get_string('text_183079f3bd54', 'local_govreporting')];
                foreach (preg_split('/\r\n|\r|\n/', $f->param1) as $value) {
                    $value = trim($value);
                    if ($value !== '') {
                        $options[$value] = $value;
                    }
                }
                $m->addElement('select', $f->shortname, $f->name, $options);
                $m->setType($f->shortname, PARAM_TEXT);
            } else if ($f->shortname === 'training_completion') {
                $m->addElement('date_selector', $f->shortname, $f->name, ['optional' => true]);
            } else {
                $attributes = ['size' => 45];
                if ($f->shortname === $focus) {
                    $attributes['autofocus'] = 'autofocus';
                }
                $m->addElement('text', $f->shortname, $f->name, $attributes);
                $m->setType($f->shortname, PARAM_TEXT);
            }
        }
        $this->add_action_buttons(true, get_string('text_60dce86db4d6', 'local_govreporting'));
    }
    /**
     * Validate submitted form values.
     *
     * @param array $data Data.
     * @param array $files Files.
     * @return array
     */
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        foreach (['BTW_Range_Clock_Hours', 'BTW_Road_Clock_Hours'] as $key) {
            $v = trim($data[$key] ?? '');
            if ($v !== '' && (!is_numeric($v) || !is_finite((float)$v) || (float)$v < 0)) {
                $errors[$key] = get_string('text_fcc28c51764a', 'local_govreporting');
            }
        }
        if (!empty($data['training_completion']) && $data['training_completion'] > time()) {
            $errors['training_completion'] = get_string('text_bf2829866fe6', 'local_govreporting');
        }
        $provider = \local_govreporting\provider_manager::for_training(['Training_Location' => $data['Training_Location'] ?? '']);
        if (!$provider) {
            $errors['Training_Location'] = get_string('text_386c15a40f53', 'local_govreporting');
        }
        return $errors;
    }
}
