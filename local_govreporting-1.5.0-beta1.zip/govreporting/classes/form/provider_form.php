<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes form provider form integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting\form;
defined('MOODLE_INTERNAL') || die();
require_once($CFG->libdir . '/formslib.php');
/**
 * Provider form for FMCSA TPR workflows.
 */
class provider_form extends \moodleform {
    /**
     * Define the form controls.
     *
     * @return void
     */
    public function definition() {
        $m = $this->_form;
        $m->addElement('hidden', 'id');
        $m->setType('id', PARAM_INT);
        $m->addElement('text', 'name', get_string('text_f688853817da', 'local_govreporting'), ['size' => 70]);
        $m->setType('name', PARAM_TEXT);
        $m->addRule('name', 'Required', 'required', null, 'client');
        $m->addElement('text', 'locationid', get_string('text_5e01632a24e8', 'local_govreporting'), ['size' => 45]);
        $m->setType('locationid', PARAM_TEXT);
        foreach (
            ['Theory' => 'Theory',
             'Range' => 'Range',
             'PublicRoad' => get_string(
                 'text_7c7448eeb4d3',
                 'local_govreporting'
             )] as $type => $label
        ) {
            $m->addElement('advcheckbox', 'supports' . $type, $label);
        }
        $owners = [0 => get_string('text_80a1b923b344', 'local_govreporting')];
        foreach (\local_govreporting\provider_manager::all() as $provider) {
            $owner = \local_govreporting\provider_manager::credential_owner($provider);
            if ($owner && $owner->id === $provider->id) {
                $owners[$provider->id] = get_string('text_0c740f10b959', 'local_govreporting') . ' ' . $provider->name;
            }
        }
        $m->addElement('select', 'credentialsource', get_string('text_acb78b0ec870', 'local_govreporting'), $owners);
        $m->setType('credentialsource', PARAM_INT);
        $default = \local_govreporting\provider_manager::default_provider('Theory');
        $owner = $default ? \local_govreporting\provider_manager::credential_owner($default) : null;
        if ($owner) {
            $m->setDefault('credentialsource', $owner->id);
        }
        $m->addElement('static', 'certificate_note', '', get_string('text_7d45a6c6ed7c', 'local_govreporting'));
        $m->addElement(
            'advcheckbox',
            'testmode',
            get_string(
                'text_43782b37f011',
                'local_govreporting'
            ),
            get_string(
                'text_4455d5ee1b39',
                'local_govreporting'
            )
        );
        $m->setDefault('testmode', 1);
        $m->addElement('advcheckbox', 'enabled', 'Enabled');
        $m->setDefault('enabled', 1);
        $this->add_action_buttons(true, get_string('text_bdf21d238cbf', 'local_govreporting'));
    }
    /**
     * Validate submitted form values.
     *
     * @param array $data Data.
     * @param array $files Files.
     * @return array
     */
    public function validation($data, $files) {
        global $DB;
        $errors = parent::validation($data, $files);
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', trim($data['locationid'] ?? ''))) {
            $errors['locationid'] = get_string('text_1f285f1944b6', 'local_govreporting');
        }
        if (empty($data['supportsTheory']) && empty($data['supportsRange']) && empty($data['supportsPublicRoad'])) {
            $errors['supportsTheory'] = get_string('text_77d5021d49bd', 'local_govreporting');
        }
        $other = $DB->get_record('local_govreporting_providers', ['name' => trim($data['name'])]);
        if ($other && $other->id != (int)($data['id'] ?? 0)) {
            $errors['name'] = get_string('text_e568b6c73469', 'local_govreporting');
        }
        $source = (int)($data['credentialsource'] ?? 0);
        if ($source && $source !== (int)($data['id'] ?? 0)) {
            $owner = \local_govreporting\provider_manager::credential_owner(\local_govreporting\provider_manager::get($source));
            if (!$owner || $owner->id === (int)($data['id'] ?? 0)) {
                $errors['credentialsource'] = get_string('text_ed2ca91c2503', 'local_govreporting');
            }
        }
        return $errors;
    }
}
