<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes btw manager integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting;

/**
 * Behind-the-wheel data, independent of theory scores and acceptance.
 */
class btw_manager extends data_manager {
    /** @var string[] Supported training-profile field shortnames. */
    const FIELDS = ['CDLProgram', 'BTW_Range_Clock_Hours', 'BTW_Road_Clock_Hours',
        'training_completion', 'Training_Location', 'Training_State', 'Training_Zip', 'Training_Street', 'Training_City'];

    /**
     * Read saved training profile fields for a student.
     *
     * @param int $userid Userid.
     * @return array
     */
    public function profile($userid) {
        global $DB;
        $values = [];
        $records = $DB->get_records_sql('SELECT f.id, f.shortname, d.data FROM {user_info_field} f
            LEFT JOIN {user_info_data} d ON d.fieldid=f.id AND d.userid=:userid', ['userid' => $userid]);
        foreach ($records as $r) {
            $values[$r->shortname] = $r->data ?? '';
        }
        return $values;
    }

    /**
     * Map the selected program to its reporting category.
     *
     * @param string $program Program.
     * @return string
     */
    public static function program_code($program) {
        $p = strtolower(trim($program));
        if (strpos($p, 'class b to a') !== false || strpos($p, 'class a') !== false) {
            return 'A';
        }
        if (strpos($p, 'class b') !== false) {
            return 'B';
        }
        if (strpos($p, 'school') !== false) {
            return 'S';
        }
        if (strpos($p, 'passenger') !== false) {
            return 'P';
        }
        return '';
    }

    /**
     * Check whether recorded hours are finite and positive.
     *
     * @param mixed $value Value.
     * @return bool
     */
    public static function valid_hours($value) {
        return is_numeric($value) && is_finite((float)$value) && (float)$value > 0;
    }

    /**
     * Check whether this training component is already accepted.
     *
     * @param int $userid Userid.
     * @param string $code Code.
     * @param string $component Component.
     * @return bool
     */
    public function accepted($userid, $code, $component) {
        global $DB;
        return $DB->record_exists('local_govreporting_btw', [
            'userid' => $userid, 'categorycode' => $code, 'component' => $component, 'status' => 'submitted']);
    }

    /**
     * Build independent range and road readiness states.
     *
     * @param int $userid Userid.
     * @param array $profile Profile.
     * @return array
     */
    public function components($userid, $profile = null) {
        $p = $profile ?? $this->profile($userid);
        $code = self::program_code($p['CDLProgram'] ?? '');
        $date = $p['training_completion'] ?? '';
        $validdate = ctype_digit((string)$date) && (int)$date > 0 && (int)$date <= time();
        $addressok = true;
        foreach (['Training_State', 'Training_Zip', 'Training_Street', 'Training_City'] as $key) {
            if (trim($p[$key] ?? '') === '' || preg_match('/^please select/i', $p[$key] ?? '')) {
                $addressok = false;
            }
        }
        $rows = [];
        foreach (['Range' => 'BTW_Range_Clock_Hours', 'PublicRoad' => 'BTW_Road_Clock_Hours'] as $type => $key) {
            $accepted = $code !== '' && $this->accepted($userid, $code, $type);
            global $DB;
            $uncertain = false;
            foreach (['pending', 'unknown'] as $status) {
                if (
                    $code !== '' && $DB->record_exists('local_govreporting_btw', [
                        'userid' => $userid, 'categorycode' => $code, 'component' => $type, 'status' => $status])
                ) {
                    $uncertain = true;
                }
            }
            $provider = provider_manager::for_training($p, $type);
            $ready = $code !== '' && self::valid_hours($p[$key] ?? '') && $validdate && $addressok && $provider;
            $configured = provider_manager::configured($provider) && preg_match('/^[0-9a-f-]{36}$/i', $provider->locationid ?? '');
            $rows[] = ['component' => $type,
                 'label' => $type === 'Range' ? 'Range' : get_string(
                     'text_7c7448eeb4d3',
                     'local_govreporting'
                 ),

                'code' => $code,
                     'providerid' => $provider->id ?? 0,
                     'providername' => $provider->name ?? get_string(
                         'text_d7deab6523d0',
                         'local_govreporting'
                     ),
                     'configured' => (bool)$configured,
                     'hours' => ($p[$key] ?? '') !== '' ? $p[$key] : get_string(
                         'text_a11319cc4f20',
                         'local_govreporting'
                     ),

                'ready' => $ready && !$accepted && !$uncertain, 'accepted' => $accepted,
                'status' => $accepted ? get_string(
                    'text_ad4eb1aafda6',
                    'local_govreporting'
                ) : ($uncertain ? get_string(
                    'text_151ed3674fc6',
                    'local_govreporting'
                ) : ($ready ? get_string(
                    'text_ae47925b5a09',
                    'local_govreporting'
                ) : get_string(
                    'text_909bf22df10b',
                    'local_govreporting'
                )))];
        }
        return $rows;
    }

    /**
     * Append a training change or submission audit record.
     *
     * @param int $userid Userid.
     * @param string $code Code.
     * @param string $component Component.
     * @param mixed $status Status.
     * @param mixed $payload Payload.
     * @param mixed $response Response.
     * @return int
     */
    public function log($userid, $code, $component, $status, $payload, $response = '') {
        global $DB, $USER;
        return $DB->insert_record('local_govreporting_btw', (object)[
            'userid' => $userid, 'categorycode' => $code, 'component' => $component, 'status' => $status,
            'payload' => json_encode($payload), 'response' => $response, 'actorid' => $USER->id, 'timecreated' => time()]);
    }

    /**
     * Append eligible/accepted BTW students before pagination and preserve theory records.
     */
    public function report_students($tab, $filters, $students) {
        global $DB;
        $result = [];
        foreach ($students as $student) {
            $result[$student->id] = $student;
        }
        if ($tab === 'submitted') {
            // Membership comes from accepted history, never mutable profile selections.
            $params = ['status' => 'submitted', 'range' => 'Range', 'road' => 'PublicRoad'];
            $categorysql = '';
            if (!empty($filters['bundleid'])) {
                $category = $this->get_enabled_bundles()[$filters['bundleid']] ?? null;
                if (!$category) {
                    return array_values($result);
                }
                $categorysql = ' AND b.categorycode=:category';
                $params['category'] = $category->classendorsementcode;
            }
            $candidates = $DB->get_records_sql('SELECT DISTINCT u.id, u.firstname, u.lastname
                FROM {user} u JOIN {local_govreporting_btw} b ON b.userid=u.id
                WHERE b.status=:status AND b.component IN (:range,:road)' . $categorysql, $params);
            // A BTW category filter can match a student whose theory is another category.
            // Attach that student's entire theory history to the same card as well.
            $historyfilters = $filters;
            unset($historyfilters['bundleid']);
            $theory = [];
            foreach ($this->get_submitted_students(0, 0, $historyfilters) as $student) {
                $theory[$student->id] = $student;
            }
            foreach ($candidates as $user) {
                if (!$this->matches_search($user, $filters) || isset($result[$user->id])) {
                    continue;
                }
                if (isset($theory[$user->id])) {
                    $result[$user->id] = $theory[$user->id];
                } else {
                    $user->courses = [];
                    $user->completed_bundles = [];
                    $user->submissions = [];
                    $result[$user->id] = $user;
                }
            }
        } else if ($tab === 'eligible') {
            $candidates = $DB->get_records_sql(
                'SELECT DISTINCT u.id, u.firstname, u.lastname FROM {user} u
                JOIN {user_info_data} d ON d.userid=u.id JOIN {user_info_field} f ON f.id=d.fieldid
                WHERE u.deleted=0 AND u.suspended=0 AND f.shortname=:field AND d.data<>:empty',
                ['field' => 'CDLProgram', 'empty' => '']
            );
            foreach ($candidates as $user) {
                if (!$this->matches_search($user, $filters)) {
                    continue;
                }
                $components = $this->report_components($user->id, 'eligible', $filters);
                if ($components && !isset($result[$user->id])) {
                    $user->courses = [];
                    $user->completed_bundles = [];
                    $user->submissions = [];
                    $result[$user->id] = $user;
                }
            }
        }
        return array_values($result);
    }

    /**
     * Only new, complete, unaccepted components are actionable in Eligible.
     */
    public function report_components($userid, $tab, $filters = [], $profile = null) {
        if ($tab !== 'eligible') {
            return [];
        }
        $category = !empty($filters['bundleid'])
            ? ($this->get_enabled_bundles()[$filters['bundleid']]->classendorsementcode ?? '') : null;
        return array_values(array_filter($this->components($userid, $profile), function ($c) use ($category) {
            return $c['ready'] && ($category === null || $c['code'] === $category);
        }));
    }

    /**
     * Payload.
     *
     * @param mixed $user User.
     * @param string $component Component.
     * @return mixed
     */
    public function payload($user, $component) {
        if (!in_array($component, ['Range', 'PublicRoad'], true)) {
            throw new \invalid_parameter_exception(get_string('text_6138ec0a3a23', 'local_govreporting'));
        }
        $group = self::require_student_group($user->id);
        $p = $this->profile($user->id);
        $entry = null;
        foreach ($this->components($user->id, $p) as $c) {
            if ($c['component'] === $component) {
                $entry = $c;
            }
        }
        if (!$entry || !$entry['ready']) {
            throw new \invalid_parameter_exception(get_string('text_8bd1eb16214c', 'local_govreporting'));
        }
        foreach (['DL', 'State', 'DOB_Month', 'DOB_Day', 'DOB_Year'] as $key) {
            if (trim($p[$key] ?? '') === '') {
                throw new \invalid_parameter_exception(get_string('text_f4a49874ced3', 'local_govreporting'));
            }
        }
        $parsedmonth = strtotime('1 ' . $p['DOB_Month'] . ' 2000');
        $month = is_numeric($p['DOB_Month']) ? (int)$p['DOB_Month'] : ($parsedmonth === false ? 0 : (int)date('n', $parsedmonth));
        if (!checkdate($month, (int)$p['DOB_Day'], (int)$p['DOB_Year'])) {
            throw new \invalid_parameter_exception(get_string('text_ceb18bb9bc81', 'local_govreporting'));
        }
        $state = strtoupper(trim($p['State']));
        $state = (new tpr_api_manager('btw', $entry['providerid']))->normalise_state($state);
        if (preg_match('/^[A-Z]{2}$/', $state)) {
            $state = 'US-' . $state;
        }
        if (!preg_match('/^US-[A-Z]{2}$/', $state)) {
            throw new \invalid_parameter_exception(get_string('text_269ae47a5295', 'local_govreporting'));
        }
        $provider = provider_manager::get($entry['providerid'], $component);
        $location = trim($provider->locationid ?? '');
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $location ?: '')) {
            throw new \invalid_parameter_exception(get_string('text_c383fd799f02', 'local_govreporting'));
        }
        $payload = ['Number' => trim($p['DL']), 'State' => $state, 'FirstName' => $user->firstname, 'LastName' => $user->lastname,
            'DateOfBirth' => sprintf('%04d-%02d-%02d', $p['DOB_Year'], $month, $p['DOB_Day']),
            'ClassEndorsementCode' => $entry['code'], 'ProviderLocationId' => $location,
            'TrainingElements' => [['TrainingType' => $component, 'CompletionDate' => date('Y-m-d', (int)$p['training_completion']),
                'Hours' => (float)$entry['hours'], 'InternalId' => $group]]];
        if (in_array($entry['code'], ['A', 'B'], true)) {
            $payload['ApplicationType'] = stripos(
                $p['CDLProgram'],
                'upgrade'
            ) !== false ||
                 stripos(
                     $p['CDLProgram'],
                     'to a'
                 ) !== false ? 'Upgrade' : 'New';
        }
        return $payload;
    }
}
