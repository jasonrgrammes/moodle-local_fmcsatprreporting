<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes privacy provider integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting\privacy;


use context_system;
use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;

/**
 * Implements Moodle privacy requests in system context.
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\core_userlist_provider,
    \core_privacy\local\request\plugin\provider {
    /**
     * @var array Tables and the personal data fields they contain.
     */
    private const TABLES = [
        'local_govreporting_submissions' => ['userid', 'bundlecourseid', 'isstandalone',
            'classendorsementcode', 'timecreated', 'timemodified', 'status', 'attempt', 'response'],
        'local_govreporting_btw' => ['userid', 'categorycode', 'component', 'status', 'payload',
            'response', 'actorid', 'timecreated'],
        'local_govreporting_archives' => ['userid', 'categorycode', 'trainingkey', 'reason',
            'archivedby', 'timecreated', 'restoredby', 'timerestored'],
    ];

    /**
     * Describe stored records and external transmission.
     * @param collection $collection Metadata collection.
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        foreach (self::TABLES as $table => $fields) {
            $map = array_fill_keys($fields, 'privacy:metadata:recordfield');
            $collection->add_database_table($table, $map, 'privacy:metadata:records');
        }
        $collection->add_subsystem_link('core_user', [], 'privacy:metadata:profile');
        $collection->add_external_location_link('fmcsa_tpr', [
            'identity' => 'privacy:metadata:identity',
            'training' => 'privacy:metadata:training',
            'group' => 'privacy:metadata:group',
        ], 'privacy:metadata:external');
        return $collection;
    }

    /**
     * Find the system context containing a person's records or staff activity.
     * @param int $userid Moodle user ID.
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        global $DB;
        $contexts = new contextlist();
        foreach (self::TABLES as $table => $unused) {
            [$where, $params] = self::where_user($table, $userid);
            if ($DB->record_exists_select($table, $where, $params)) {
                $contexts->add_system_context();
                break;
            }
        }
        return $contexts;
    }

    /**
     * Find all students and staff referenced by the plugin.
     * @param userlist $userlist Context-scoped user list.
     */
    public static function get_users_in_context(userlist $userlist) {
        if ($userlist->get_context()->contextlevel !== CONTEXT_SYSTEM) {
            return;
        }
        foreach (self::TABLES as $table => $unused) {
            foreach (self::user_fields($table) as $field) {
                $userlist->add_from_sql($field, "SELECT $field FROM {{$table}} WHERE $field > 0", []);
            }
        }
    }

    /**
     * Export the student's records and redacted staff-activity references.
     * @param approved_contextlist $contextlist Approved contexts.
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;
        $context = context_system::instance();
        if (!in_array($context->id, $contextlist->get_contextids())) {
            return;
        }
        $userid = (int)$contextlist->get_user()->id;
        foreach (self::TABLES as $table => $unused) {
            [$where, $params] = self::where_user($table, $userid);
            $records = $DB->get_records_select($table, $where, $params, 'id ASC');
            foreach ($records as $record) {
                // A staff request must not disclose another student's identity or payload.
                if ((int)$record->userid !== $userid) {
                    $record = (object)['id' => $record->id,
                        'activity' => get_string('text_37add55059e4', 'local_govreporting'),
                        'timecreated' => $record->timecreated ?? 0];
                }
                writer::with_context($context)->export_data([
                    get_string('pluginname', 'local_govreporting'), $table, (string)$record->id,
                ], $record);
            }
        }
    }

    /**
     * Erase all plugin personal data after an approved system-context deletion.
     * @param \context $context Approved context.
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        if ($context->contextlevel === CONTEXT_SYSTEM) {
            foreach (self::TABLES as $table => $unused) {
                $DB->delete_records($table);
            }
        }
    }

    /**
     * Erase a student's records and anonymize that person's staff references.
     * @param approved_contextlist $contextlist Approved contexts.
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        if (in_array(context_system::instance()->id, $contextlist->get_contextids())) {
            self::delete_user((int)$contextlist->get_user()->id);
        }
    }

    /**
     * Erase the approved user set in system context.
     * @param approved_userlist $userlist Approved users.
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        if ($userlist->get_context()->contextlevel === CONTEXT_SYSTEM) {
            foreach ($userlist->get_userids() as $userid) {
                self::delete_user((int)$userid);
            }
        }
    }

    /**
     * Erase local data only. This never alters a government-held certification.
     * @param int $userid User being erased.
     */
    private static function delete_user(int $userid): void {
        global $DB;
        foreach (self::TABLES as $table => $unused) {
            $DB->delete_records($table, ['userid' => $userid]);
            foreach (array_diff(self::user_fields($table), ['userid']) as $field) {
                $DB->set_field($table, $field, 0, [$field => $userid]);
            }
        }
    }

    /**
     * User-reference fields for a table.
     * @param string $table Table name from the fixed table map.
     * @return array
     */
    private static function user_fields(string $table): array {
        if ($table === 'local_govreporting_btw') {
            return ['userid', 'actorid'];
        }
        if ($table === 'local_govreporting_archives') {
            return ['userid', 'archivedby', 'restoredby'];
        }
        return ['userid'];
    }

    /**
     * Build portable user-reference conditions from the fixed table map.
     * @param string $table Table name.
     * @param int $userid User ID.
     * @return array SQL and parameters.
     */
    private static function where_user(string $table, int $userid): array {
        $conditions = [];
        $params = [];
        foreach (self::user_fields($table) as $field) {
            $conditions[] = "$field = :$field";
            $params[$field] = $userid;
        }
        return [implode(' OR ', $conditions), $params];
    }
}
