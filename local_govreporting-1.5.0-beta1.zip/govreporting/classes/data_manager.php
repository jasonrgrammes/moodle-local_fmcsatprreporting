<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes data manager integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting;


/**
 * Class data_manager
 *
 * This class manages data retrieval and processing for the Government Reporting plugin.
 * Optimized for handling all students and courses.
 */
class data_manager {
    /**
     * Placeholder labels are not an assigned reporting group.
     */
    public static function valid_group($value) {
        $value = trim((string)$value);
        return $value !== '' && !preg_match('/^(?:(?:please\s+)?(?:select|choose)\b|not\s+assigned$)/iu', $value);
    }

    /**
     * Read the current saved profile, never a stale report or supplied API object.
     */
    public static function student_group($userid) {
        global $DB;
        $field = $DB->get_record('user_info_field', ['shortname' => 'Group']);
        $record = $field ? $DB->get_record('user_info_data', ['userid' => $userid, 'fieldid' => $field->id]) : false;
        return trim((string)($record->data ?? ''));
    }

    /**
     * Require student group.
     *
     * @param int $userid Userid.
     * @return mixed
     */
    public static function require_student_group($userid) {
        $group = self::student_group($userid);
        if (!self::valid_group($group)) {
            throw new \invalid_parameter_exception(get_string('text_1f93a97c3f1c', 'local_govreporting'));
        }
        return $group;
    }

    /**
     * @var array Cache for eligible students (keyed by filter hash)
     */
    private static $eligiblestudentscache = [];

    /**
     * @var array Cache for user courses
     */
    private static $usercoursescache = [];

    /**
     * @var array Cache for user grades
     */
    private static $usergradescache = [];

    /**
     * Get all enabled bundles.
     *
     * @return array List of enabled bundles
     */
    /**
     * Match names in PHP so search never becomes executable SQL.
     */
    protected function matches_search($user, $filters) {
        global $DB;
        if (isset($filters['group']) && $filters['group'] !== '') {
            $groupfield = $DB->get_record('user_info_field', ['shortname' => 'Group']);
            $grouprecord = $groupfield ? $DB->get_record(
                'user_info_data',
                ['fieldid' => $groupfield->id, 'userid' => $user->id],
                'data'
            ) : false;
            if (!$grouprecord || $grouprecord->data !== $filters['group']) {
                return false;
            }
        }
        foreach (['firstinitial' => 'firstname', 'lastinitial' => 'lastname'] as $filter => $field) {
            $initial = $filters[$filter] ?? '';
            if (
                $initial !== '' && \core_text::strtolower(\core_text::substr(trim($user->$field), 0, 1)) !==
                    \core_text::strtolower($initial)
            ) {
                return false;
            }
        }
        return true;
    }


    /**
     * Distinguish a later training result from the completion that was dismissed.
     */
    public function reporting_training_key($userid, $category) {
        global $DB;
        $ids = array_values(array_filter(array_map('intval', explode(',', $category->courseids))));
        sort($ids);
        if (!$ids) {
            throw new \invalid_parameter_exception(get_string('text_715845d2f942', 'local_govreporting'));
        }
        [$insql, $params] = $DB->get_in_or_equal($ids, SQL_PARAMS_NAMED, 'course');
        $params['userid'] = $userid;
        $grades = $DB->get_records_sql("SELECT gi.courseid, g.finalgrade, g.timemodified
            FROM {grade_items} gi JOIN {grade_grades} g ON g.itemid = gi.id
            WHERE gi.itemtype = 'course' AND gi.courseid $insql AND g.userid = :userid
            ORDER BY gi.courseid", $params);
        return hash('sha256', json_encode([$category->classendorsementcode, $ids, array_values($grades)]));
    }

    /**
     * Is reporting archived.
     *
     * @param int $userid Userid.
     * @param mixed $category Category.
     * @return mixed
     */
    protected function is_reporting_archived($userid, $category) {
        global $DB;
        return $DB->record_exists('local_govreporting_archives', [
            'userid' => $userid, 'categorycode' => $category->classendorsementcode,
            'trainingkey' => $this->reporting_training_key($userid, $category), 'timerestored' => 0,
        ]);
    }

    /**
     * Does not edit or manufacture any government submission record.
     */
    public function archive_reporting($userid, $categoryid, $reason, $actorid) {
        global $DB;
        $student = null;
        $category = null;
        foreach ($this->get_eligible_students() as $candidate) {
            if ($candidate->id != $userid) {
                continue;
            }
            $student = $candidate;
            foreach ($candidate->completed_bundles as $completed) {
                if ($completed['bundle']->id == $categoryid) {
                    $category = $completed['bundle'];
                    break;
                }
            }
            break;
        }
        if (!$student || !$category) {
            throw new \invalid_parameter_exception(get_string('text_9b805f4ced25', 'local_govreporting'));
        }
        $id = $DB->insert_record('local_govreporting_archives', (object)[
            'userid' => $userid, 'categorycode' => $category->classendorsementcode,
            'trainingkey' => $this->reporting_training_key($userid, $category),
            'reason' => $reason, 'archivedby' => $actorid, 'timecreated' => time(),
            'restoredby' => 0, 'timerestored' => 0,
        ]);
        self::$eligiblestudentscache = [];
        return $id;
    }

    /**
     * Restore reporting.
     *
     * @param mixed $archiveid Archiveid.
     * @param int $actorid Actorid.
     * @return mixed
     */
    public function restore_reporting($archiveid, $actorid) {
        global $DB;
        $record = $DB->get_record('local_govreporting_archives', ['id' => $archiveid], '*', MUST_EXIST);
        if (!$record->timerestored) {
            $record->restoredby = $actorid;
            $record->timerestored = time();
            $DB->update_record('local_govreporting_archives', $record);
        }
        self::$eligiblestudentscache = [];
    }

    /**
     * Get archived students.
     *
     * @param mixed $offset Offset.
     * @param mixed $limit Limit.
     * @param array $filters Filters.
     * @return mixed
     */
    public function get_archived_students($offset = 0, $limit = 0, $filters = []) {
        global $DB;
        $records = $DB->get_records_sql("SELECT a.id as archiveid, a.userid, a.categorycode,
            a.reason, a.timecreated, u.firstname, u.lastname, u.id
            FROM {local_govreporting_archives} a JOIN {user} u ON u.id = a.userid
            WHERE a.timerestored = 0 ORDER BY a.timecreated DESC, a.id DESC");
        $users = [];
        $matching = [];
        $category = $this->get_enabled_bundles()[$filters['bundleid'] ?? 0] ?? null;
        foreach ($records as $record) {
            if (!$this->matches_search($record, $filters)) {
                continue;
            }
            if (!isset($users[$record->userid])) {
                $users[$record->userid] = (object)['id' => $record->userid,
                    'firstname' => $record->firstname, 'lastname' => $record->lastname, 'courses' => [], 'archives' => []];
            }
            $users[$record->userid]->archives[] = $record;
            if (!$category || $record->categorycode === $category->classendorsementcode) {
                $matching[$record->userid] = true;
            }
        }
        $users = array_values(array_intersect_key($users, $matching));
        return $limit ? array_slice($users, $offset, $limit) : $users;
    }

    /**
     * Get enabled bundles.
     *
     * @return mixed
     */
    public function get_enabled_bundles() {
        // Reporting curricula are independent of retail packages. Negative IDs avoid
        // collisions with legacy bundle IDs and preserve every legacy submission.
        return [
            -101 => (object)['id' => -101,
                 'name' => get_string(
                     'text_65ea6ad132c8',
                     'local_govreporting'
                 ),
                 'classendorsementcode' => 'A',
                 'courseids' => (string)get_config(
                     'local_govreporting',
                     'curriculum_A'
                 )],

            -102 => (object)['id' => -102,
                 'name' => get_string(
                     'text_78fcc50b6093',
                     'local_govreporting'
                 ),
                 'classendorsementcode' => 'B',
                 'courseids' => (string)get_config(
                     'local_govreporting',
                     'curriculum_B'
                 )],

            -103 => (object)['id' => -103,
                 'name' => get_string(
                     'text_d6d6c26958c0',
                     'local_govreporting'
                 ),
                 'classendorsementcode' => 'H',
                 'courseids' => (string)get_config(
                     'local_govreporting',
                     'curriculum_H'
                 )],

            -104 => (object)['id' => -104,
                 'name' => 'Passenger',
                 'classendorsementcode' => 'P',
                 'courseids' => (string)get_config(
                     'local_govreporting',
                     'curriculum_P'
                 )],

            -105 => (object)['id' => -105,
                 'name' => get_string(
                     'text_bdbf8ae5c96f',
                     'local_govreporting'
                 ),
                 'classendorsementcode' => 'S',
                 'courseids' => (string)get_config(
                     'local_govreporting',
                     'curriculum_S'
                 )],

        ];
    }

    /**
     * Check if a user has completed all courses in a bundle with the minimum score.
     *
     * @param int $userid The user ID
     * @param object $bundle The bundle object
     * @param int $minscore The minimum score percentage
     * @return array|false Array of completed courses with scores, or false if not all completed
     */
    protected function check_bundle_completion($userid, $bundle, $minscore) {
        if (empty($bundle->courseids)) {
            return false;
        }

        $courseids = explode(',', $bundle->courseids);
        $completedcourses = [];

        foreach ($courseids as $courseid) {
            $courseid = intval($courseid);
            if (!$courseid) {
                continue;
            }

            // Check if user is enrolled in this course.
            if (!$this->is_user_enrolled($userid, $courseid)) {
                return false; // Not enrolled in all courses.
            }

            // Get the grade for this course.
            $score = $this->get_course_grade_percentage_optimized($userid, $courseid);

            if ($score < $minscore) {
                return false; // Didn't meet minimum score in all courses.
            }

            $completedcourses[] = [
                'courseid' => $courseid,
                'score' => $score,
            ];
        }

        return $completedcourses;
    }

    /**
     * Check if a user is enrolled in a specific course.
     *
     * @param int $userid The user ID
     * @param int $courseid The course ID
     * @return bool True if enrolled, false otherwise
     */
    protected function is_user_enrolled($userid, $courseid) {
        global $DB;

        $sql = "SELECT COUNT(*)
                FROM {user_enrolments} ue
                JOIN {enrol} e ON e.id = ue.enrolid
                WHERE ue.userid = ? AND e.courseid = ?";

        return $DB->count_records_sql($sql, [$userid, $courseid]) > 0;
    }

    /**
     * Check if a bundle submission already exists for a user.
     *
     * @param int $userid The user ID
     * @param int $bundleid The bundle ID
     * @param string $classendorsementcode The class/endorsement code
     * @return bool True if already submitted, false otherwise
     */
    protected function is_bundle_submitted($userid, $bundleid, $classendorsementcode) {
        global $DB;

        if ($bundleid < 0) {
            return $DB->record_exists('local_govreporting_submissions', [
                'userid' => $userid,
                'classendorsementcode' => $classendorsementcode,
                'status' => 'submitted',
            ]);
        }
        return $DB->record_exists('local_govreporting_submissions', [
            'userid' => $userid,
            'bundlecourseid' => $bundleid,
            'classendorsementcode' => $classendorsementcode,
            'status' => 'submitted',
            'isstandalone' => 0,
        ]);
    }

    /**
     * Get all students who are eligible for government reporting.
     * Eligible students are those who have scored at or above the minimum percentage
     * in ALL their courses and have not been successfully submitted yet.
     *
     * @param int $limitfrom Offset for pagination
     * @param int $limitnum Number of records to return
     * @param array $filters Optional filters (categoryid, subcategoryid, courseid)
     * @return array List of eligible students with their details
     */
    public function get_eligible_students($limitfrom = 0, $limitnum = 0, $filters = []) {
        global $DB;

        // Create a cache key that includes filters.
        $cachekey = md5(json_encode($filters));

        // Use in-memory cache to avoid recalculating for pagination
        // But cache must be filter-specific.
        if (isset(self::$eligiblestudentscache[$cachekey])) {
            if ($limitnum > 0) {
                return array_slice(self::$eligiblestudentscache[$cachekey], $limitfrom, $limitnum);
            }
            return self::$eligiblestudentscache[$cachekey];
        }

        // Get minimum score threshold from settings.
        $minscore = get_config('local_govreporting', 'minscore');
        if (empty($minscore)) {
            $minscore = 80; // Default is 80% if not set.
        }

        $minscore = max(80, (float)$minscore);

        // Get all enabled bundles.
        $bundles = $this->get_enabled_bundles();

        if (empty($bundles)) {
            return []; // No bundles configured, no eligible students.
        }

        // Filter bundles based on bundle ID if specified.
        if (!empty($filters['bundleid'])) {
            $filteredbundles = [];
            foreach ($bundles as $bundle) {
                if ($bundle->id == $filters['bundleid']) {
                    $filteredbundles[] = $bundle;
                    break;
                }
            }
            $bundles = $filteredbundles;

            if (empty($bundles)) {
                return []; // Selected bundle not found or not enabled.
            }
        }

        // Filter bundles based on category/subcategory/course criteria.
        if (!empty($filters['categoryid']) || !empty($filters['subcategoryid']) || !empty($filters['courseid'])) {
            $bundles = $this->filter_bundles_by_criteria($bundles, $filters);

            if (empty($bundles)) {
                return []; // No bundles match the filter criteria.
            }
        }

        // Process users in batches to avoid memory issues.
        $userbatchsize = 500; // Number of users to process at once.
        $useroffset = 0;
        $allusers = [];

        do {
            // SQL to find users with the required profile fields in batches.
            $sql = "SELECT DISTINCT u.id, u.firstname, u.lastname, u.email, u.picture, u.imagealt,
                           u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename
                    FROM {user} u
                    WHERE u.deleted = 0 AND u.suspended = 0 AND u.confirmed = 1
                    ORDER BY u.id";

            $userbatch = $DB->get_records_sql($sql, [], $useroffset, $userbatchsize);

            if (empty($userbatch)) {
                break; // No more users to process.
            }

            $batchcount = count($userbatch);
            foreach ($userbatch as $key => $user) {
                if (!$this->matches_search($user, $filters)) {
                    unset($userbatch[$key]);
                }
            }
            $allusers += $userbatch; // Merge batches.
            $useroffset += $userbatchsize;
        } while ($batchcount == $userbatchsize);

        // Get profile fields for all users in one query.
        $profilefields = [];
        if (!empty($allusers)) {
            $userids = array_keys($allusers);
            [$insql, $inparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'profileuser');

            // Get all required profile fields in one query with a JOIN.
            $sql = "SELECT uid.userid, uif.shortname, uid.data
                    FROM {user_info_data} uid
                    JOIN {user_info_field} uif ON uif.id = uid.fieldid
                    WHERE uid.userid $insql
                    AND uif.shortname IN ('DL',
                        'DOB_Month',
                        'DOB_Day',
                        'DOB_Year',
                        'State',
                        'training_completion',
                        'theory_score',
                        'Group',
                        'group',
                        'CDLProgram')";

            $profiledata = $DB->get_recordset_sql($sql, $inparams);

            // Organize profile data by user and field.
            foreach ($profiledata as $profile) {
                if (!isset($profilefields[$profile->userid])) {
                    $profilefields[$profile->userid] = [];
                }
                $profilefields[$profile->userid][$profile->shortname] = $profile->data;
            }
            $profiledata->close();

            // Assign profile fields to user objects.
            foreach ($allusers as $userid => $user) {
                if (isset($profilefields[$userid])) {
                    $fields = $profilefields[$userid];
                    $user->driver_license = isset($fields['DL']) ? $fields['DL'] : '';

                    // Combine DOB fields (DOB_Month, DOB_Day, DOB_Year) into YYYY-MM-DD format.
                    $dobmonth = isset($fields['DOB_Month']) ? trim($fields['DOB_Month']) : '';
                    $dobday = isset($fields['DOB_Day']) ? trim($fields['DOB_Day']) : '';
                    $dobyear = isset($fields['DOB_Year']) ? trim($fields['DOB_Year']) : '';

                    // Check if any field contains a numeric timestamp (like 274770000).
                    $dobtimestamp = null;
                    if (is_numeric($dobmonth) && strlen($dobmonth) > 5) {
                        $dobtimestamp = intval($dobmonth);
                    } else if (is_numeric($dobday) && strlen($dobday) > 5) {
                        $dobtimestamp = intval($dobday);
                    } else if (is_numeric($dobyear) && strlen($dobyear) > 5) {
                        $dobtimestamp = intval($dobyear);
                    }

                    if ($dobtimestamp && $dobtimestamp > 0) {
                        // Convert timestamp to date (handle both Unix timestamp and other formats)
                        // If timestamp is very large, it might be in milliseconds.
                        if ($dobtimestamp > 2147483647) {
                            $dobtimestamp = $dobtimestamp / 1000;
                        }
                        $user->date_of_birth = date('Y-m-d', $dobtimestamp);
                    } else if (!empty($dobmonth) && !empty($dobday) && !empty($dobyear)) {
                        // Convert month name to number if needed.
                        $monthnum = $this->convert_month_to_number($dobmonth);
                        if ($monthnum) {
                            // Format as YYYY-MM-DD.
                            $user->date_of_birth = sprintf('%04d-%02d-%02d', intval($dobyear), $monthnum, intval($dobday));
                        } else {
                            // Try to parse as date string.
                            $user->date_of_birth = '';
                        }
                    } else {
                        $user->date_of_birth = '';
                    }

                    $user->state = isset($fields['State']) ? $fields['State'] : '';
                    $user->training_completion = isset($fields['training_completion']) ? $fields['training_completion'] : '';
                    $user->theory_score = isset($fields['theory_score']) ? $fields['theory_score'] : '';

                    // Get Group field (check both capital and lowercase).
                    $user->group = '';
                    if (isset($fields['Group'])) {
                        $user->group = $fields['Group'];
                    } else if (isset($fields['group'])) {
                        $user->group = $fields['group'];
                    }
                }
            }
        }

        // Process all users and filter for eligible ones (those who completed at least one bundle).
        $eligiblestudents = [];
        $eligiblestudentsmap = []; // Track by user ID to avoid duplicates.

        foreach ($allusers as $user) {
            $program = \core_text::strtolower(trim($profilefields[$user->id]['CDLProgram'] ?? ''));
            // Check the reporting curriculum selected in the student's profile.
            $completedbundles = [];

            foreach ($bundles as $definition) {
                $bundle = clone $definition;
                if ($bundle->classendorsementcode === 'A') {
                    if (strpos($program, 'class a') === false && strpos($program, 'class b to a') === false) {
                        continue;
                    }
                    if (strpos($program, 'restricted') !== false) {
                        $bundle->courseids = (string)get_config('local_govreporting', 'curriculum_A_restricted');
                    }
                } else if ($bundle->classendorsementcode === 'B') {
                    if (strpos($program, 'class b') === false || strpos($program, 'to a') !== false) {
                        continue;
                    }
                }
                // Check if already submitted.
                if ($this->is_bundle_submitted($user->id, $bundle->id, $bundle->classendorsementcode)) {
                    continue; // Already submitted this bundle.
                }

                // Check if user completed all courses in this bundle.
                $bundlecourses = $this->check_bundle_completion($user->id, $bundle, $minscore);

                if ($bundlecourses !== false) {
                    if (empty($filters['include_archived']) && $this->is_reporting_archived($user->id, $bundle)) {
                        continue;
                    }
                    // User completed this reporting curriculum.
                    $completedbundles[] = [
                        'bundle' => $bundle,
                        'courses' => $bundlecourses,
                    ];
                }
            }

            // If user completed at least one bundle, add them to eligible list.
            if (!empty($completedbundles)) {
                // Only add each user once (they may have completed multiple bundles).
                if (!isset($eligiblestudentsmap[$user->id])) {
                    // Add profile image URL.
                    global $PAGE;
                    $userpicture = new \user_picture($user);
                    $userpicture->size = 200; // Large size for avatar.
                    $user->profileimageurl = $userpicture->get_url($PAGE)->out(false);

                    // Store completed bundles info.
                    $user->completed_bundles = $completedbundles;

                    // Build courses array for backward compatibility with report page.
                    $user->courses = [];
                    $totalscore = 0;
                    $coursecount = 0;
                    $courseidsseen = []; // Track unique courses.

                    foreach ($completedbundles as $cb) {
                        foreach ($cb['courses'] as $courseinfo) {
                            $courseid = $courseinfo['courseid'];

                            // Only add each course once (might be in multiple bundles).
                            if (!isset($courseidsseen[$courseid])) {
                                $course = $DB->get_record('course', ['id' => $courseid], 'id, fullname, shortname');
                                if ($course) {
                                    $course->score = $courseinfo['score'];
                                    $user->courses[] = $course;
                                    $courseidsseen[$courseid] = true;
                                }
                            }

                            $totalscore += $courseinfo['score'];
                            $coursecount++;
                        }
                    }
                    $user->average_score = $coursecount > 0 ? round($totalscore / $coursecount, 2) : 0;

                    $eligiblestudentsmap[$user->id] = $user;
                    $eligiblestudents[] = $user;
                }
            }
        }

        // Cache results for later use (for pagination) - use filter-specific cache key.
        self::$eligiblestudentscache[$cachekey] = $eligiblestudents;

        // Return all students or a subset if pagination is required.
        if ($limitnum > 0) {
            return array_slice($eligiblestudents, $limitfrom, $limitnum);
        }

        return $eligiblestudents;
    }

    /**
     * Filter bundles based on category/subcategory/course criteria.
     * Only returns bundles that contain at least one course matching the filter.
     *
     * @param array $bundles List of bundles to filter
     * @param array $filters Filter criteria (categoryid, subcategoryid, courseid)
     * @return array Filtered list of bundles
     */
    protected function filter_bundles_by_criteria($bundles, $filters) {
        global $DB;

        if (empty($bundles)) {
            return [];
        }

        $filteredbundles = [];

        foreach ($bundles as $bundle) {
            if (empty($bundle->courseids)) {
                continue; // Skip bundles with no courses.
            }

            $bundlecourseids = explode(',', $bundle->courseids);
            $matchesfilter = false;

            // Check if this bundle contains courses matching the filter.
            if (!empty($filters['courseid'])) {
                // Specific course filter - bundle must contain this exact course.
                if (in_array($filters['courseid'], $bundlecourseids)) {
                    $matchesfilter = true;
                }
            } else if (!empty($filters['subcategoryid'])) {
                // Subcategory filter - bundle must contain at least one course in this subcategory or its children.
                $categoryids = $this->get_category_and_children($filters['subcategoryid']);

                foreach ($bundlecourseids as $courseid) {
                    $courseid = intval($courseid);
                    if (!$courseid) {
                        continue;
                    }

                    $course = $DB->get_record('course', ['id' => $courseid], 'id, category');
                    if ($course && in_array($course->category, $categoryids)) {
                        $matchesfilter = true;
                        break;
                    }
                }
            } else if (!empty($filters['categoryid'])) {
                // Category filter - bundle must contain at least one course in this category or its children.
                $categoryids = $this->get_category_and_children($filters['categoryid']);

                foreach ($bundlecourseids as $courseid) {
                    $courseid = intval($courseid);
                    if (!$courseid) {
                        continue;
                    }

                    $course = $DB->get_record('course', ['id' => $courseid], 'id, category');
                    if ($course && in_array($course->category, $categoryids)) {
                        $matchesfilter = true;
                        break;
                    }
                }
            }

            // Add bundle to filtered list if it matches.
            if ($matchesfilter) {
                $filteredbundles[] = $bundle;
            }
        }

        return $filteredbundles;
    }

    /**
     * Get courses for a specific user, optimized with caching.
     *
     * @param int $userid The user ID
     * @param array $filters Optional filters (categoryid, subcategoryid, courseid)
     * @return array List of courses the user is enrolled in
     */
    protected function get_user_courses_optimized($userid, $filters = []) {
        global $DB;

        // Generate cache key based on filters.
        $cachekey = $userid . '_' . implode('_', $filters);

        // Check cache first.
        if (isset(self::$usercoursescache[$cachekey])) {
            return self::$usercoursescache[$cachekey];
        }

        // Base SQL query.
        $sql = "SELECT DISTINCT c.id, c.fullname, c.shortname, c.category
                FROM {course} c
                JOIN {enrol} e ON e.courseid = c.id
                JOIN {user_enrolments} ue ON ue.enrolid = e.id
                WHERE ue.userid = :userid AND c.id != :siteid";

        $params = ['userid' => $userid, 'siteid' => SITEID];

        // Apply filters.
        if (!empty($filters['courseid'])) {
            $sql .= " AND c.id = :courseid";
            $params['courseid'] = $filters['courseid'];
        } else if (!empty($filters['subcategoryid'])) {
            // Get all courses in this subcategory and its children.
            $subcatids = $this->get_category_and_children($filters['subcategoryid']);
            if (!empty($subcatids)) {
                [$insql, $inparams] = $DB->get_in_or_equal($subcatids, SQL_PARAMS_NAMED);
                $sql .= " AND c.category $insql";
                $params = array_merge($params, $inparams);
            }
        } else if (!empty($filters['categoryid'])) {
            // Get all courses in this category and its children.
            $catids = $this->get_category_and_children($filters['categoryid']);
            if (!empty($catids)) {
                [$insql, $inparams] = $DB->get_in_or_equal($catids, SQL_PARAMS_NAMED);
                $sql .= " AND c.category $insql";
                $params = array_merge($params, $inparams);
            }
        }

        $courses = $DB->get_records_sql($sql, $params);

        // Cache the result.
        self::$usercoursescache[$cachekey] = $courses;

        return $courses;
    }

    /**
     * Get the grade percentage for a user in a specific course, optimized with caching.
     *
     * @param int $userid The user ID
     * @param int $courseid The course ID
     * @return float The grade percentage (0-100)
     */
    protected function get_course_grade_percentage_optimized($userid, $courseid) {
        global $DB;

        // Check cache first.
        if (isset(self::$usergradescache[$userid]) && isset(self::$usergradescache[$userid][$courseid])) {
            return self::$usergradescache[$userid][$courseid];
        }

        // Initialize cache for this user if needed.
        if (!isset(self::$usergradescache[$userid])) {
            self::$usergradescache[$userid] = [];
        }

        try {
            // Optimized direct query for better performance.
            $sql = "SELECT gi.grademax, g.finalgrade
                    FROM {grade_items} gi
                    JOIN {grade_grades} g ON gi.id = g.itemid
                    WHERE gi.courseid = ?
                    AND gi.itemtype = 'course'
                    AND g.userid = ?";

            $graderecord = $DB->get_record_sql($sql, [$courseid, $userid]);

            // Calculate grade if possible.
            if ($graderecord && !is_null($graderecord->finalgrade) && !empty($graderecord->grademax)) {
                $gradepercentage = round(($graderecord->finalgrade / $graderecord->grademax) * 100, 2);

                // Cache the result.
                self::$usergradescache[$userid][$courseid] = $gradepercentage;

                return $gradepercentage;
            }

            // Cache the zero result.
            self::$usergradescache[$userid][$courseid] = 0;
            return 0;
        } catch (\Exception $e) {
            // Cache the zero result.
            self::$usergradescache[$userid][$courseid] = 0;
            return 0;
        }
    }

    /**
     * Count the total number of eligible students.
     *
     * @param array $filters Optional filters (categoryid, subcategoryid, courseid)
     * @return int Number of eligible students
     */
    public function count_eligible_students($filters = []) {
        // Create cache key.
        $cachekey = md5(json_encode($filters));

        // If we already have the eligible students cached, just count them.
        if (isset(self::$eligiblestudentscache[$cachekey])) {
            return count(self::$eligiblestudentscache[$cachekey]);
        }

        // Otherwise, we need to get the eligible students first (which will cache them).
        $allstudents = $this->get_eligible_students(0, 0, $filters);
        return count($allstudents);
    }

    /**
     * Get all students who have been successfully submitted to the government.
     *
     * @param int $limitfrom Offset for pagination
     * @param int $limitnum Number of records to return
     * @param array $filters Optional filters (categoryid, subcategoryid, courseid)
     * @return array List of submitted students with their details
     */
    public function get_submitted_students($limitfrom = 0, $limitnum = 0, $filters = []) {
        global $DB;

        // Get minimum score threshold from settings.
        $minscore = get_config('local_govreporting', 'minscore');
        if (empty($minscore)) {
            $minscore = 80; // Default is 80% if not set.
        }

        // Get users who have been successfully submitted.
        // Key by submission ID first: Moodle keys result arrays by the first column.
        // Group before pagination so one student never loses another accepted record.
        $sql = "SELECT s.id as submissionid, s.userid, s.timecreated as submission_date,
                       s.timemodified as last_modified, s.attempt, s.response,
                       s.bundlecourseid, s.isstandalone, s.classendorsementcode,
                       u.firstname, u.lastname, u.email, u.picture, u.imagealt,
                       u.firstnamephonetic, u.lastnamephonetic, u.middlename,
                       u.alternatename, u.id as id
                  FROM {local_govreporting_submissions} s
                  JOIN {user} u ON u.id = s.userid
                 WHERE s.status = 'submitted'
              ORDER BY s.timemodified DESC, s.id DESC";
        $records = $DB->get_records_sql($sql);
        $submittedusers = [];
        $matchingusers = [];
        foreach ($records as $record) {
            if (!$this->matches_search($record, $filters)) {
                continue;
            }
            $userid = $record->userid;
            if (!isset($submittedusers[$userid])) {
                $submittedusers[$userid] = clone $record;
                $submittedusers[$userid]->submissions = [];
            }
            $submittedusers[$userid]->submissions[] = $record;
            $categorymatches = empty($filters['bundleid']);
            if (!$categorymatches) {
                if ($filters['bundleid'] < 0) {
                    $categories = $this->get_enabled_bundles();
                    $selectedcode = $categories[$filters['bundleid']]->classendorsementcode ?? '';
                    $categorymatches = $record->classendorsementcode === $selectedcode;
                } else {
                    $categorymatches = !$record->isstandalone && $record->bundlecourseid == $filters['bundleid'];
                }
            }
            if ($categorymatches) {
                $matchingusers[$userid] = true;
            }
        }
        $submittedusers = array_intersect_key($submittedusers, $matchingusers);
        if ($limitnum > 0) {
            $submittedusers = array_slice($submittedusers, $limitfrom, $limitnum, true);
        }

        if (empty($submittedusers)) {
            return [];
        }

        $userids = array_keys($submittedusers);
            [$insql, $inparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'profileuser');

        // Get profile fields for all users in one query.
        $profilefields = [];
        if (!empty($userids)) {
            // Get all required profile fields in one query with a JOIN.
            $sql = "SELECT uid.userid, uif.shortname, uid.data
                    FROM {user_info_data} uid
                    JOIN {user_info_field} uif ON uif.id = uid.fieldid
                    WHERE uid.userid $insql
                    AND uif.shortname IN ('DL',
                        'DOB_Month',
                        'DOB_Day',
                        'DOB_Year',
                        'State',
                        'training_completion',
                        'theory_score',
                        'Group',
                        'group')";

            $profiledata = $DB->get_recordset_sql($sql, $inparams);

            // Organize profile data by user and field.
            foreach ($profiledata as $profile) {
                if (!isset($profilefields[$profile->userid])) {
                    $profilefields[$profile->userid] = [];
                }
                $profilefields[$profile->userid][$profile->shortname] = $profile->data;
            }
            $profiledata->close();
        }

        // Process all submitted users.
        $submittedstudents = [];

        foreach ($submittedusers as $userid => $user) {
            // Assign profile fields to user objects.
            if (isset($profilefields[$userid])) {
                $fields = $profilefields[$userid];
                $user->driver_license = isset($fields['DL']) ? $fields['DL'] : '';

                // Combine DOB fields (DOB_Month, DOB_Day, DOB_Year) into YYYY-MM-DD format.
                $dobmonth = isset($fields['DOB_Month']) ? trim($fields['DOB_Month']) : '';
                $dobday = isset($fields['DOB_Day']) ? trim($fields['DOB_Day']) : '';
                $dobyear = isset($fields['DOB_Year']) ? trim($fields['DOB_Year']) : '';

                // Check if any field contains a numeric timestamp (like 274770000).
                $dobtimestamp = null;
                if (is_numeric($dobmonth) && strlen($dobmonth) > 5) {
                    $dobtimestamp = intval($dobmonth);
                } else if (is_numeric($dobday) && strlen($dobday) > 5) {
                    $dobtimestamp = intval($dobday);
                } else if (is_numeric($dobyear) && strlen($dobyear) > 5) {
                    $dobtimestamp = intval($dobyear);
                }

                if ($dobtimestamp && $dobtimestamp > 0) {
                    // Convert timestamp to date (handle both Unix timestamp and other formats)
                    // If timestamp is very large, it might be in milliseconds.
                    if ($dobtimestamp > 2147483647) {
                        $dobtimestamp = $dobtimestamp / 1000;
                    }
                    $user->date_of_birth = date('Y-m-d', $dobtimestamp);
                } else if (!empty($dobmonth) && !empty($dobday) && !empty($dobyear)) {
                    // Convert month name to number if needed.
                    $monthnum = $this->convert_month_to_number($dobmonth);
                    if ($monthnum) {
                        // Format as YYYY-MM-DD.
                        $user->date_of_birth = sprintf('%04d-%02d-%02d', intval($dobyear), $monthnum, intval($dobday));
                    } else {
                        // Try to parse as date string.
                        $user->date_of_birth = '';
                    }
                } else {
                    $user->date_of_birth = '';
                }

                $user->state = isset($fields['State']) ? $fields['State'] : '';
                $user->training_completion = isset($fields['training_completion']) ? $fields['training_completion'] : '';
                $user->theory_score = isset($fields['theory_score']) ? $fields['theory_score'] : '';

                // Get Group field (check both capital and lowercase).
                $user->group = '';
                if (isset($fields['Group'])) {
                    $user->group = $fields['Group'];
                } else if (isset($fields['group'])) {
                    $user->group = $fields['group'];
                }
            }

            // Get the bundle that was submitted for this user.
            $submittedbundle = null;
            if (!empty($user->bundlecourseid)) {
                $submittedbundle = $DB->get_record('local_govreporting_bundles', ['id' => $user->bundlecourseid]);
            }

            // Get courses for this user - use bundle courses if available, otherwise all courses.
            if ($submittedbundle && !empty($submittedbundle->courseids)) {
                // Calculate average from bundle courses only.
                $bundlecourseids = explode(',', $submittedbundle->courseids);
                $bundlecourses = [];
                $averagescore = 0;
                $totalcourses = 0;

                foreach ($bundlecourseids as $courseid) {
                    $courseid = intval($courseid);
                    if (!$courseid) {
                        continue;
                    }

                    $course = $DB->get_record('course', ['id' => $courseid], 'id, fullname, shortname');
                    if ($course) {
                        $score = $this->get_course_grade_percentage_optimized($user->id, $courseid);
                        $course->score = $score;
                        $bundlecourses[] = $course;
                        $totalcourses++;
                        $averagescore += $score;
                    }
                }

                // Calculate average score from bundle courses.
                if ($totalcourses > 0) {
                    $averagescore = $averagescore / $totalcourses;
                }

                $user->courses = $bundlecourses;
                $user->average_score = round($averagescore, 2);
            } else {
                // Fallback to all courses if bundle not found.
                $courses = $this->get_user_courses_optimized($user->id, $filters);

                if (!empty($courses)) {
                    $highscorecourses = [];
                    $averagescore = 0;
                    $totalcourses = 0;

                    foreach ($courses as $course) {
                        $score = $this->get_course_grade_percentage_optimized($user->id, $course->id);
                        $course->score = $score;
                        $totalcourses++;
                        $averagescore += $score;

                        if ($score >= $minscore) {
                            $highscorecourses[] = $course;
                        }
                    }

                    // Calculate average score.
                    if ($totalcourses > 0) {
                        $averagescore = $averagescore / $totalcourses;
                    }

                    $user->courses = $highscorecourses;
                    $user->average_score = round($averagescore, 2);
                } else {
                    $user->courses = [];
                    $user->average_score = 0;
                }
            }

            // Format submission date.
            $user->submission_date_formatted = date('Y-m-d H:i:s', $user->submission_date);
            $user->last_modified_formatted = date('Y-m-d H:i:s', $user->last_modified);

            // Add profile image URL.
            global $PAGE;
            $userpicture = new \user_picture($user);
            $userpicture->size = 200; // Large size for avatar.
            $user->profileimageurl = $userpicture->get_url($PAGE)->out(false);

            $submittedstudents[] = $user;
        }

        return $submittedstudents;
    }

    /**
     * Count the total number of submitted students.
     *
     * @param array $filters Optional filters (categoryid, subcategoryid, courseid)
     * @return int Number of submitted students
     */
    public function count_submitted_students($filters = []) {
        $students = $this->get_submitted_students(0, 0, $filters);
        return count($students);
    }

    /**
     * Update the theory_score profile field for a user.
     *
     * @param int $userid The user ID
     * @param float $score The average score to set
     * @return bool Success or failure
     */
    protected function update_theory_score($userid, $score) {
        global $DB;

        // First get the field ID for theory_score.
        $fieldid = $DB->get_field('user_info_field', 'id', ['shortname' => 'theory_score']);

        if (!$fieldid) {
            return false; // Field doesn't exist.
        }

        // Check if the record already exists.
        $existing = $DB->get_record('user_info_data', [
            'userid' => $userid,
            'fieldid' => $fieldid,
        ]);

        if ($existing) {
            // Update existing record.
            $existing->data = $score;
            return $DB->update_record('user_info_data', $existing);
        } else {
            // Create new record.
            $record = new \stdClass();
            $record->userid = $userid;
            $record->fieldid = $fieldid;
            $record->data = $score;
            return $DB->insert_record('user_info_data', $record) ? true : false;
        }
    }

    /**
     * Record a submission attempt for a student.
     *
     * @param int $userid The user ID
     * @param string $status The submission status (pending, submitted, failed)
     * @param string $response The API response
     * @param int $bundlecourseid The bundle or course ID
     * @param string $classendorsementcode The class/endorsement code
     * @param int $isstandalone Whether this is a standalone course (1) or bundle (0)
     * @return int The ID of the new submission record
     */
    public function record_submission(
        $userid,
        $status,
        $response = '',
        $bundlecourseid = 0,
        $classendorsementcode = 'A',
        $isstandalone = 0
    ) {
        global $DB;

        self::$eligiblestudentscache = [];
        $submission = new \stdClass();
        $submission->userid = $userid;
        $submission->bundlecourseid = $bundlecourseid;
        $submission->isstandalone = $isstandalone;
        $submission->classendorsementcode = $classendorsementcode;
        $submission->timecreated = time();
        $submission->timemodified = time();
        $submission->status = $status;
        $submission->response = $response;

        // Check if there's an existing submission for this user + bundle/course + endorsement code.
        $existing = $DB->get_record('local_govreporting_submissions', [
            'userid' => $userid,
            'bundlecourseid' => $bundlecourseid,
            'classendorsementcode' => $classendorsementcode,
        ]);

        if ($existing) {
            $submission->id = $existing->id;
            $submission->attempt = $existing->attempt + 1;
            $DB->update_record('local_govreporting_submissions', $submission);
            return $existing->id;
        } else {
            $submission->attempt = 1;
            return $DB->insert_record('local_govreporting_submissions', $submission);
        }
    }

    /**
     * Update theory scores for all eligible students.
     * This should be run as a separate task, not during report generation.
     */
    public function update_all_theory_scores() {
        global $DB;

        // Get all users.
        $users = $DB->get_records('user', ['deleted' => 0, 'suspended' => 0, 'confirmed' => 1], '', 'id');

        foreach ($users as $user) {
            $courses = $this->get_user_courses_optimized($user->id);

            if (empty($courses)) {
                continue; // Skip users not enrolled in any courses.
            }

            $averagescore = 0;
            $totalcourses = 0;

            foreach ($courses as $course) {
                $score = $this->get_course_grade_percentage_optimized($user->id, $course->id);
                $totalcourses++;
                $averagescore += $score;
            }

            // Calculate average score.
            if ($totalcourses > 0) {
                $averagescore = $averagescore / $totalcourses;
                $this->update_theory_score($user->id, round($averagescore, 2));
            }
        }
    }

    /**
     * Get all top-level course categories.
     *
     * @return array List of categories
     */
    public function get_all_categories() {
        global $DB;

        // Get all top-level categories (parent = 0).
        $categories = $DB->get_records('course_categories', ['parent' => 0], 'sortorder, name', 'id, name, parent');

        $result = [];
        foreach ($categories as $category) {
            $result[] = [
                'id' => $category->id,
                'name' => $category->name,
            ];
        }

        return $result;
    }

    /**
     * Get subcategories for a given parent category.
     *
     * @param int $parentid Parent category ID (0 for top-level)
     * @return array List of subcategories
     */
    public function get_subcategories($parentid = 0) {
        global $DB;

        if (empty($parentid)) {
            return [];
        }

        // Get direct children of this category.
        $subcategories = $DB->get_records('course_categories', ['parent' => $parentid], 'sortorder, name', 'id, name, parent');

        $result = [];
        foreach ($subcategories as $subcategory) {
            $result[] = [
                'id' => $subcategory->id,
                'name' => $subcategory->name,
            ];
        }

        return $result;
    }

    /**
     * Get courses for filter dropdown.
     *
     * @param int $categoryid Category ID filter
     * @param int $subcategoryid Subcategory ID filter
     * @return array List of courses
     */
    public function get_courses_for_filter($categoryid = 0, $subcategoryid = 0) {
        global $DB;

        // If no category is selected, return empty array
        // This prevents showing all courses when no filter is applied.
        if (empty($categoryid) && empty($subcategoryid)) {
            return [];
        }

        $sql = "SELECT id, fullname, shortname, category
                FROM {course}
                WHERE id != :siteid";

        $params = ['siteid' => SITEID];

        if (!empty($subcategoryid)) {
            // Get courses in subcategory and its children.
            $catids = $this->get_category_and_children($subcategoryid);
            if (!empty($catids)) {
                [$insql, $inparams] = $DB->get_in_or_equal($catids, SQL_PARAMS_NAMED);
                $sql .= " AND category $insql";
                $params = array_merge($params, $inparams);
            } else {
                // Invalid subcategory, return empty.
                return [];
            }
        } else if (!empty($categoryid)) {
            // Get courses in category and its children.
            $catids = $this->get_category_and_children($categoryid);
            if (!empty($catids)) {
                [$insql, $inparams] = $DB->get_in_or_equal($catids, SQL_PARAMS_NAMED);
                $sql .= " AND category $insql";
                $params = array_merge($params, $inparams);
            } else {
                // Invalid category, return empty.
                return [];
            }
        }

        $sql .= " ORDER BY fullname";

        $courses = $DB->get_records_sql($sql, $params);

        $result = [];
        foreach ($courses as $course) {
            $result[] = [
                'id' => $course->id,
                'name' => $course->fullname,
            ];
        }

        return $result;
    }

    /**
     * Get ALL courses in the system for direct course filter.
     *
     * @return array List of all courses
     */
    public function get_all_courses_for_filter() {
        global $DB;

        $sql = "SELECT id, fullname, shortname, category
                FROM {course}
                WHERE id != :siteid
                ORDER BY fullname";

        $courses = $DB->get_records_sql($sql, ['siteid' => SITEID]);

        $result = [];
        foreach ($courses as $course) {
            $result[] = [
                'id' => $course->id,
                'name' => $course->fullname,
            ];
        }

        return $result;
    }

    /**
     * Get a category and all its children recursively.
     *
     * @param int $categoryid Category ID
     * @return array Array of category IDs including the parent
     */
    protected function get_category_and_children($categoryid) {
        global $DB;

        if (empty($categoryid)) {
            return [];
        }

        $categoryids = [$categoryid];

        // Get all children recursively.
        $children = $DB->get_records('course_categories', ['parent' => $categoryid], '', 'id');

        foreach ($children as $child) {
            $childids = $this->get_category_and_children($child->id);
            $categoryids = array_merge($categoryids, $childids);
        }

        return $categoryids;
    }

    /**
     * Convert month name or number to numeric month (1-12)
     *
     * @param string $month Month name (e.g., "July", "Jul") or number (e.g., "7", "07")
     * @return int|false Month number (1-12) or false if invalid
     */
    protected function convert_month_to_number($month) {
        $month = trim($month);

        // If it's already a number, validate and return.
        if (is_numeric($month)) {
            $monthnum = intval($month);
            if ($monthnum >= 1 && $monthnum <= 12) {
                return $monthnum;
            }
            return false;
        }

        // Convert month name to number.
        $monthnames = [
            'january' => 1, 'jan' => 1,
            'february' => 2, 'feb' => 2,
            'march' => 3, 'mar' => 3,
            'april' => 4, 'apr' => 4,
            'may' => 5,
            'june' => 6, 'jun' => 6,
            'july' => 7, 'jul' => 7,
            'august' => 8, 'aug' => 8,
            'september' => 9, 'sep' => 9, 'sept' => 9,
            'october' => 10, 'oct' => 10,
            'november' => 11, 'nov' => 11,
            'december' => 12, 'dec' => 12,
        ];

        $monthlower = strtolower($month);
        if (isset($monthnames[$monthlower])) {
            return $monthnames[$monthlower];
        }

        return false;
    }
}
