<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR classes provider manager integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_govreporting;

/**
 * Configurable FMCSA TPR provider locations. Signing keys stay in private configuration.
 */
class provider_manager {
    /**
     * Return enabled provider locations for the requested training component.
     *
     * @param string $component Component.
     * @return array
     */
    public static function all($component = '') {
        global $DB;
        $rows = $DB->get_records('local_govreporting_providers', ['enabled' => 1], 'name ASC');
        if ($component === '') {
            return $rows;
        }
        return array_filter($rows, function ($p) use ($component) {
            return in_array($component, explode(',', $p->components), true);
        });
    }
    /**
     * Return one enabled provider location.
     *
     * @param int $id Id.
     * @param string $component Component.
     * @return \stdClass|null
     */
    public static function get($id, $component = '') {
        $rows = self::all($component);
        return $rows[$id] ?? null;
    }
    /**
     * Resolve the default location for a training component.
     *
     * @param string $component Component.
     * @return \stdClass|null
     */
    public static function default_provider($component) {
        $key = $component === 'Theory' ? 'tpr_theory_provider_id' : 'tpr_btw_provider_id';
        return self::get((int)get_config('local_govreporting', $key), $component);
    }
    /**
     * Resolve the provider from a student training profile.
     *
     * @param array $profile Profile.
     * @param string $component Component.
     * @return \stdClass|null
     */
    public static function for_training($profile, $component = 'Range') {
        $name = trim($profile['Training_Location'] ?? '');
        foreach (self::all($component) as $p) {
            if ($p->name === $name) {
                return $p;
            }
        }
        // A legacy theory-only choice does not control the behind-the-wheel route.
        if ($name !== '') {
            foreach (self::all('Theory') as $p) {
                if ($p->name === $name && !in_array($component, explode(',', $p->components), true)) {
                    return self::default_provider($component);
                }
            }
            return null;
        }
        return self::default_provider($component);
    }
    /**
     * Resolve the signing-credential configuration prefix.
     *
     * @param mixed $provider Provider.
     * @param mixed $test Test.
     * @return string
     */
    public static function prefix($provider, $test = null) {
        $provider = self::credential_owner($provider);
        if (!$provider) {
            throw new \invalid_parameter_exception(get_string('text_6e14f68a4897', 'local_govreporting'));
        }
        $test = $test ?? (bool)$provider->testmode;
        if (!empty($provider->legacytheory)) {
            return $test ? 'tpr_test_' : 'tpr_';
        }
        return 'tpr_provider_' . $provider->id . ($test ? '_test_' : '_');
    }
    /**
     * Check whether a location has its required signing configuration.
     *
     * @param mixed $provider Provider.
     * @return bool
     */
    public static function configured($provider) {
        if (!$provider || !self::credential_owner($provider)) {
            return false;
        }
        $prefix = self::prefix($provider);
        return !empty(get_config('local_govreporting', $prefix . 'credentialid'))
            && !empty(get_config('local_govreporting', $prefix . 'privatekey'));
    }
    /**
     * Follow shared-certificate mappings while rejecting cycles.
     *
     * @param mixed $provider Provider.
     * @return \stdClass|null
     */
    public static function credential_owner($provider) {
        $seen = [];
        while ($provider) {
            if (isset($seen[$provider->id])) {
                return null;
            }
            $seen[$provider->id] = true;
            $source = (int)get_config('local_govreporting', 'credentialsource_' . $provider->id);
            if (!$source || $source === $provider->id) {
                return $provider;
            }
            $provider = self::get($source);
        }
        return null;
    }
    /**
     * Determine whether the selected credentials use the test configuration.
     *
     * @param mixed $provider Provider.
     * @return bool
     */
    public static function is_testmode($provider) {
        $owner = self::credential_owner($provider);
        return $owner ? (bool)$owner->testmode : true;
    }
}
