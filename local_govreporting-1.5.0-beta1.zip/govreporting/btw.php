<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR btw integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_login();
$context = context_system::instance();
require_capability('local/govreporting:viewreport', $context);
$userid = optional_param('userid', 0, PARAM_INT);
$action = optional_param('action', 'edit', PARAM_ALPHA);
$component = optional_param('component', '', PARAM_ALPHA);
$returntab = optional_param('returntab', 'eligible', PARAM_ALPHA);
if (!in_array($returntab, ['eligible', 'submitted'], true)) {
    $returntab = 'eligible';
}
$url = new moodle_url(
    '/local/govreporting/btw.php',
    ['userid' => $userid,
     'action' => $action,
     'component' => $component,
    'returntab' => $returntab]
);
$PAGE->set_context($context);
$PAGE->set_url($url);
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('text_ce701413ab41', 'local_govreporting'));
$PAGE->set_heading(get_string('text_ce701413ab41', 'local_govreporting'));
$manager = new \local_govreporting\btw_manager();
$back = new moodle_url('/local/govreporting/report.php', ['tab' => $returntab]);
if (!$userid) {
    $q = optional_param('q', '', PARAM_TEXT);
    echo $OUTPUT->header();
    echo html_writer::div(
        html_writer::link(
            new moodle_url(
                '/admin/category.php',
                ['category' => 'local_govreporting_settings']
            ),
            get_string(
                'text_77fd1c923852',
                'local_govreporting'
            ),
            ['class' => 'btn btn-outline-secondary mb-3']
        ),
        'tpr-report-return'
    );
    echo $OUTPUT->heading(get_string('text_4191cbba7a12', 'local_govreporting'));
    echo html_writer::start_tag('form', ['method' => 'get', 'action' => $url->out(false)]);
    echo html_writer::label(get_string('text_d3857f3b46ca', 'local_govreporting'), 'student-query');
    echo html_writer::empty_tag('input', ['id' => 'student-query', 'name' => 'q', 'value' => $q, 'class' => 'form-control']);
    echo html_writer::tag(
        'button',
        get_string(
            'text_6b9acc705643',
            'local_govreporting'
        ),
        ['type' => 'submit',
        'class' => 'btn btn-primary mt-2']
    );
    echo html_writer::end_tag('form');
    if ($q !== '') {
        $like = '%' . $DB->sql_like_escape($q) . '%';
        $where = 'deleted=0 AND suspended=0 AND (' .
             $DB->sql_like(
                 'firstname',
                 ':first',
                 false
             ) .
             ' OR ' .
             $DB->sql_like(
                 'lastname',
                 ':last',
                 false
             ) .
             ')';
        $users = $DB->get_records_select(
            'user',
            $where,
            ['first' => $like,
             'last' => $like],
            'lastname,firstname',
            'id,firstname,lastname',
            0,
            50
        );
        echo html_writer::start_tag('ul');
        foreach ($users as $u) {
            echo html_writer::tag(
                'li',
                html_writer::link(
                    new moodle_url(
                        '/local/govreporting/btw.php',
                        ['userid' => $u->id]
                    ),
                    s(fullname($u))
                )
            );
        }
        echo html_writer::end_tag('ul');
        if (count($users) === 50) {
            echo html_writer::tag('p', get_string('text_aaae0226a425', 'local_govreporting'));
        }
    }
    echo html_writer::link($back, get_string('text_909a7b0ac14e', 'local_govreporting'));
    echo $OUTPUT->footer();
    exit;
}
$student = $DB->get_record('user', ['id' => $userid, 'deleted' => 0], 'id,firstname,lastname', MUST_EXIST);
$profile = $manager->profile($userid);
$fingerprint = function ($payload, $profile, $provider) {
    return hash(
        'sha256',
        json_encode([$payload,
         array_intersect_key(
             $profile,
             array_flip(['Training_Location',
             'Training_State',
             'Training_Zip',
             'Training_Street',
             'Training_City'])
         ),
         $provider->id,
        \local_govreporting\provider_manager::is_testmode($provider)])
    );
};
if ($action === 'review' || $action === 'send') {
    if (!is_siteadmin()) {
        throw new required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
    }
    $provider = \local_govreporting\provider_manager::for_training($profile, $component);
    if (!$provider || !\local_govreporting\provider_manager::configured($provider)) {
        throw new invalid_parameter_exception(get_string('text_afaae5f2954f', 'local_govreporting'));
    }
    $payload = $manager->payload($student, $component);
    if ($action === 'send') {
        require_sesskey();
        if (!data_submitted() || !required_param('locationconfirmed', PARAM_BOOL)) {
            throw new invalid_parameter_exception(get_string('text_e1869e860ada', 'local_govreporting'));
        }
        $factory = \core\lock\lock_config::get_lock_factory('local_govreporting');
        $lock = $factory->get_lock('submit-student-' . $userid, 10);
        if (!$lock) {
            throw new moodle_exception(get_string('text_1c3992d64556', 'local_govreporting'));
        }
        try {
            $payload = $manager->payload($student, $component);
            $profile = $manager->profile($userid);
            $provider = \local_govreporting\provider_manager::for_training($profile, $component);
            if (
                !$provider ||
                 !hash_equals(
                     $fingerprint(
                         $payload,
                         $profile,
                         $provider
                     ),
                     required_param(
                         'reviewhash',
                         PARAM_ALPHANUM
                     )
                 )
            ) {
                throw new invalid_parameter_exception(get_string('text_bc8824fa7181', 'local_govreporting'));
            }
            $profile['Training_Location'] = $provider->name;
            $student->btw_payload = $payload;
            $attemptid = $manager->log(
                $userid,
                $payload['ClassEndorsementCode'],
                $component,
                'pending',
                ['request' => $payload,
                     'training_address' => array_intersect_key(
                         $profile,
                         array_flip(['Training_Location',
                         'Training_State',
                         'Training_Zip',
                         'Training_Street',
                         'Training_City'])
                     )]
            );
            $result = (new \local_govreporting\tpr_api_manager('btw', $provider->id))->submit_training_data($student);
            $test = (bool)\local_govreporting\provider_manager::is_testmode($provider);
            $status = $result['success'] ? ($test ? 'tested' : 'submitted') : ($result['code'] ? 'failed' : 'unknown');
            $DB->update_record(
                'local_govreporting_btw',
                (object)['id' => $attemptid,
                 'status' => $status,
                'response' => json_encode($result)]
            );
        } finally {
            $lock->release();
        }
        redirect(
            $back,
            $test && $result['success'] ? get_string('text_ce19b75c6fa8', 'local_govreporting') : $result['message'],
            null,
            $result['success'] ? \core\output\notification::NOTIFY_SUCCESS : \core\output\notification::NOTIFY_ERROR
        );
    }
    echo $OUTPUT->header();
    echo html_writer::div(
        html_writer::link(
            new moodle_url(
                '/admin/category.php',
                ['category' => 'local_govreporting_settings']
            ),
            get_string(
                'text_77fd1c923852',
                'local_govreporting'
            ),
            ['class' => 'btn btn-outline-secondary mb-3']
        ),
        'tpr-report-return'
    );
    echo $OUTPUT->heading(s('Review ' .
         ($component === 'Range' ? 'range' : get_string(
             'text_f3a3b50faff0',
             'local_govreporting'
         )) .
         ' submission: ' .
         fullname($student)));
    $test = (bool)\local_govreporting\provider_manager::is_testmode($provider);
    echo $OUTPUT->notification(
        $test ? get_string(
            'text_cf4c525162f3',
            'local_govreporting'
        ) : get_string(
            'text_3dc379feb194',
            'local_govreporting'
        ),
        \core\output\notification::NOTIFY_INFO
    );
    echo html_writer::tag('p', s('Provider: ' . $provider->name));
    echo html_writer::tag(
        'p',
        s(get_string(
            'text_7caa7952073e',
            'local_govreporting'
        ) .
         ' ' .
        $payload['TrainingElements'][0]['InternalId'])
    );
    echo html_writer::tag(
        'p',
        s('License: ' .
         $payload['Number'] .
         ' / ' .
         $payload['State'] .
         ' ' .
         get_string(
             'text_4c97957328b0',
             'local_govreporting'
         ) .
         ' ' .
        $payload['DateOfBirth'])
    );
    echo html_writer::tag(
        'p',
        s('Category ' .
         $payload['ClassEndorsementCode'] .
         ' — ' .
         $payload['TrainingElements'][0]['Hours'] .
         ' ' .
         get_string(
             'text_0cfe293a4f34',
             'local_govreporting'
         ) .
         ' ' .
        $payload['TrainingElements'][0]['CompletionDate'])
    );
    echo html_writer::tag(
        'p',
        s(implode(
            ', ',
            array_filter([$profile['Training_Street'] ?? '',
             $profile['Training_City'] ?? '',
             $profile['Training_State'] ?? '',
            $profile['Training_Zip'] ?? ''])
        ))
    );
    echo html_writer::tag('p', get_string('text_fe1d987dfb32', 'local_govreporting'));
    echo html_writer::start_tag('form', ['method' => 'post', 'action' => $url->out(false)]);
    foreach (
        ['userid' => $userid,
         'action' => 'send',
         'component' => $component,
         'sesskey' => sesskey(),
         'reviewhash' => $fingerprint(
             $payload,
             $profile,
             $provider
         )] as $key => $value
    ) {
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => $key, 'value' => $value]);
    }
    echo html_writer::tag(
        'label',
        html_writer::empty_tag(
            'input',
            ['type' => 'checkbox',
             'name' => 'locationconfirmed',
             'value' => 1,
            'required' => 'required']
        ) .
         ' ' .
         get_string(
             'text_f3e8b38741ac',
             'local_govreporting'
         )
    );
    echo html_writer::tag(
        'div',
        html_writer::tag(
            'button',
            $test ? get_string(
                'text_c28a3b872e2c',
                'local_govreporting'
            ) : get_string(
                'text_cfd0aefe8496',
                'local_govreporting'
            ),
            ['type' => 'submit',
            'class' => 'btn btn-primary']
        )
    );
    echo html_writer::end_tag('form');
    echo $OUTPUT->footer();
    exit;
}
$fields = [];
foreach ($DB->get_records('user_info_field', null, 'sortorder') as $f) {
    if (in_array($f->shortname, \local_govreporting\btw_manager::FIELDS, true)) {
        $fields[] = $f;
    }
}
$form = new \local_govreporting\form\btw_form($url, ['fields' => $fields, 'focuscomponent' => $component]);
if ($form->is_cancelled()) {
    redirect($back);
}
if ($data = $form->get_data()) {
    require_sesskey();
    $factory = \core\lock\lock_config::get_lock_factory('local_govreporting');
    $editlock = $factory->get_lock('submit-student-' . $userid, 10);
    if (!$editlock) {
        throw new moodle_exception(get_string('text_d06962f696d6', 'local_govreporting'));
    }
    try {
        $profile = $manager->profile($userid);
        $transaction = $DB->start_delegated_transaction();
        $changes = [];
        foreach ($fields as $f) {
            $key = $f->shortname;
            $value = (string)($data->$key ?? '');
            if ($value === (string)($profile[$key] ?? '')) {
                continue;
            }
            $record = $DB->get_record('user_info_data', ['userid' => $userid, 'fieldid' => $f->id]);
            $changes[$key] = ['before' => $profile[$key] ?? '', 'after' => $value];
            if ($record) {
                $record->data = $value;
                $DB->update_record('user_info_data', $record);
            } else {
                $DB->insert_record(
                    'user_info_data',
                    (object)['userid' => $userid,
                     'fieldid' => $f->id,
                     'data' => $value,
                    'dataformat' => 0]
                );
            }
        }
        if ($changes) {
            $manager->log($userid, '', 'Profile', 'edited', $changes);
        }
        $transaction->allow_commit();
    } finally {
        $editlock->release();
    }
    redirect($back, get_string('text_e493b67a7d54', 'local_govreporting'));
}
$currentprovider = \local_govreporting\provider_manager::for_training($profile);
$form->set_data((object)array_merge($profile, ['userid' => $userid, 'Training_Location' => $currentprovider->name ?? '']));
echo $OUTPUT->header();
echo html_writer::div(
    html_writer::link(
        new moodle_url(
            '/admin/category.php',
            ['category' => 'local_govreporting_settings']
        ),
        get_string(
            'text_77fd1c923852',
            'local_govreporting'
        ),
        ['class' => 'btn btn-outline-secondary mb-3']
    ),
    'tpr-report-return'
);
echo $OUTPUT->heading(s(fullname($student)));
echo $OUTPUT->notification(get_string('text_40e2c5259f86', 'local_govreporting'), \core\output\notification::NOTIFY_INFO);
$form->display();
echo $OUTPUT->footer();
