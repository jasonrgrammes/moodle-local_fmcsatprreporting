<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR settings integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
global $DB;

// This is the main admin page for the plugin.
if ($hassiteconfig) {
    $ADMIN->add(
        'localplugins',
        new admin_category(
            'local_govreporting_settings',
            get_string(
                'text_33f5515938f0',
                'local_govreporting'
            )
        )
    );

    // Main report page.
    $ADMIN->add('local_govreporting_settings', new admin_externalpage(
        'local_govreporting_report',
        get_string('text_ef45857bd842', 'local_govreporting'),
        new moodle_url('/local/govreporting/report.php')
    ));

    // FMCSA TPR certificate management page.
    $ADMIN->add('local_govreporting_settings', new admin_externalpage(
        'local_govreporting_certificates',
        get_string('text_9a20896fe95e', 'local_govreporting'),
        new moodle_url('/local/govreporting/providers.php')
    ));

    // Settings page.
    $settings = new admin_settingpage('local_govreporting_config', get_string('settings', 'local_govreporting'));
    $ADMIN->add('local_govreporting_settings', $settings);

    $reporturl = new moodle_url('/admin/category.php', ['category' => 'local_govreporting_settings']);
    $settings->add(new admin_setting_heading(
        'local_govreporting/report_return',
        '',
        html_writer::link(
            $reporturl,
            get_string(
                'text_77fd1c923852',
                'local_govreporting'
            ),
            ['class' => 'btn btn-outline-secondary']
        )
    ));

    // Minimum score percentage.
    $settings->add(new admin_setting_configtext(
        'local_govreporting/minscore',
        get_string('minscore', 'local_govreporting'),
        get_string('minscoredesc', 'local_govreporting'),
        '80',
        PARAM_INT
    ));

    // Students per page setting.
    $settings->add(new admin_setting_configtext(
        'local_govreporting/perpage',
        get_string('perpage', 'local_govreporting'),
        get_string('perpagedesc', 'local_govreporting'),
        '10',
        PARAM_INT
    ));

    // FMCSA TPR API Settings Section.
    $settings->add(new admin_setting_heading(
        'local_govreporting/tpr_settings',
        get_string('tpr_settings_heading', 'local_govreporting'),
        get_string('tpr_settings_desc', 'local_govreporting')
    ));

    $providersurl = new moodle_url('/local/govreporting/providers.php');
    $settings->add(new admin_setting_heading(
        'local_govreporting/provider_heading',
        get_string('text_f62bd375025a', 'local_govreporting'),
        html_writer::link(
            $providersurl,
            get_string(
                'text_4598548629aa',
                'local_govreporting'
            )
        ) .
             get_string(
                 'text_ed37d6ef2c4c',
                 'local_govreporting'
             )
    ));
    $theoryproviders = [0 => get_string('text_5a3fd82caf0f', 'local_govreporting')];
    $btwproviders = [0 => get_string('text_08ffbfda4ed3', 'local_govreporting')];
    if ($DB->get_manager()->table_exists('local_govreporting_providers')) {
        foreach (\local_govreporting\provider_manager::all() as $provider) {
            $types = explode(',', $provider->components);
            if (in_array('Theory', $types, true)) {
                $theoryproviders[$provider->id] = $provider->name;
            }
            if (in_array('Range', $types, true) && in_array('PublicRoad', $types, true)) {
                $btwproviders[$provider->id] = $provider->name;
            }
        }
    }
    $settings->add(new admin_setting_configselect(
        'local_govreporting/tpr_theory_provider_id',
        get_string(
            'text_771b534ef560',
            'local_govreporting'
        ),
        get_string(
            'text_8735583a8927',
            'local_govreporting'
        ),
        0,
        $theoryproviders
    ));
    $settings->add(new admin_setting_configselect(
        'local_govreporting/tpr_btw_provider_id',
        get_string(
            'text_f8999ee2fc1b',
            'local_govreporting'
        ),
        get_string(
            'text_629693cf3aa6',
            'local_govreporting'
        ),
        0,
        $btwproviders
    ));
    $courseoptions = [];
    foreach ($DB->get_records('course', null, 'fullname ASC', 'id,fullname') as $course) {
        if ($course->id != SITEID) {
            $courseoptions[$course->id] = $course->fullname;
        }
    }
    $settings->add(new admin_setting_heading(
        'local_govreporting/curriculum_heading',
        get_string(
            'text_49a33a802a9f',
            'local_govreporting'
        ),
        get_string(
            'text_6aef23a00ea1',
            'local_govreporting'
        )
    ));
    foreach (
        ['A' => get_string(
            'text_65ea6ad132c8',
            'local_govreporting'
        ),
         'B' => get_string(
             'text_78fcc50b6093',
             'local_govreporting'
         ),
         'H' => get_string(
             'text_d6d6c26958c0',
             'local_govreporting'
         ),
         'P' => 'Passenger',
         'S' => get_string(
             'text_bdbf8ae5c96f',
             'local_govreporting'
         ),
         'A_restricted' => get_string(
             'text_13f2b260be37',
             'local_govreporting'
         )] as $code => $label
    ) {
        $settings->add(new admin_setting_configmultiselect(
            'local_govreporting/curriculum_' .
             $code,
            $label .
             ' ' .
             get_string(
                 'text_c821899da829',
                 'local_govreporting'
             ),
            '',
            [],
            $courseoptions
        ));
    }
}
