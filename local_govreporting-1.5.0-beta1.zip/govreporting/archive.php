<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR archive integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_login();
$context = context_system::instance();
require_capability('local/govreporting:viewreport', $context);
if (!is_siteadmin()) {
    throw new required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
}
if (!data_submitted()) {
    throw new moodle_exception('invalidrequest');
}
require_sesskey();
$action = required_param('action', PARAM_ALPHA);
$manager = new \local_govreporting\data_manager();
$archiveid = optional_param('archiveid', 0, PARAM_INT);
$userid = optional_param('userid', 0, PARAM_INT);
if ($action === 'restore') {
    $record = $DB->get_record('local_govreporting_archives', ['id' => $archiveid], '*', MUST_EXIST);
    $userid = $record->userid;
}
$factory = \core\lock\lock_config::get_lock_factory('local_govreporting');
$lock = $factory->get_lock('submit-student-' . $userid, 10);
if (!$lock) {
    throw new moodle_exception('locktimeout');
}
try {
    if ($action === 'archive') {
        $reasoncode = optional_param('reason', 'dismissed', PARAM_ALPHA);
        $reason = $reasoncode === 'reported' ? get_string(
            'text_eb66c5130562',
            'local_govreporting'
        ) : get_string(
            'text_55f2e7d89aa8',
            'local_govreporting'
        );
        $manager->archive_reporting($userid, required_param('categoryid', PARAM_INT), $reason, $USER->id);
        $message = get_string('text_ff49ee832131', 'local_govreporting');
        $tab = 'archived';
    } else if ($action === 'restore') {
        $manager->restore_reporting($archiveid, $USER->id);
        $message = get_string('text_c1b36084c171', 'local_govreporting');
        $tab = 'eligible';
    } else {
        throw new invalid_parameter_exception(get_string('text_09a9c661e9f2', 'local_govreporting'));
    }
} finally {
    $lock->release();
}
redirect(
    new moodle_url(
        '/local/govreporting/report.php',
        ['tab' => $tab]
    ),
    $message,
    null,
    \core\output\notification::NOTIFY_SUCCESS
);
