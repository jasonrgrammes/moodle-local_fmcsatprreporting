<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Regression tests for independent reporting components and student privacy.
 *
 * @package local_govreporting
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_govreporting;

use core_privacy\local\request\approved_contextlist;
use PHPUnit\Framework\Attributes\CoversClass;

/**
 * Tests reporting behaviour using synthetic data without network requests.
 */
#[CoversClass(data_manager::class)]
#[CoversClass(btw_manager::class)]
#[CoversClass(output\report_page::class)]
#[CoversClass(privacy\provider::class)]
final class reporting_test extends \advanced_testcase {
    /**
     * Prepare an isolated test and clear request-local reporting caches.
     */
    protected function setUp(): void {
        global $CFG;
        parent::setUp();
        $this->resetAfterTest();
        $this->setAdminUser();
        require_once($CFG->dirroot . '/local/govreporting/lib.php');
        require_once($CFG->libdir . '/gradelib.php');
        local_govreporting_install_profile_fields();
        $this->clear_report_caches();
    }

    /**
     * Clear the caches between synthetic grade changes.
     */
    private function clear_report_caches(): void {
        foreach (['eligiblestudentscache', 'usercoursescache', 'usergradescache'] as $name) {
            $property = new \ReflectionProperty(data_manager::class, $name);
            $property->setValue(null, []);
        }
    }

    /**
     * Save one synthetic custom profile value.
     *
     * @param int $userid Student user ID.
     * @param string $name Profile field shortname.
     * @param string $value Synthetic value.
     */
    private function profile_value(int $userid, string $name, string $value): void {
        global $DB;
        $field = $DB->get_record('user_info_field', ['shortname' => $name], '*', MUST_EXIST);
        $record = $DB->get_record('user_info_data', ['userid' => $userid, 'fieldid' => $field->id]);
        if ($record) {
            $record->data = $value;
            $DB->update_record('user_info_data', $record);
        } else {
            $DB->insert_record('user_info_data', (object)[
                'userid' => $userid, 'fieldid' => $field->id, 'data' => $value, 'dataformat' => 0,
            ]);
        }
    }

    /**
     * Create synthetic identity and actual training details, with no signing credentials.
     *
     * @return \stdClass Student user.
     */
    private function student(): \stdClass {
        global $DB;
        $student = $this->getDataGenerator()->create_user();
        $values = [
            'Group' => 'Training group', 'CDLProgram' => 'Class A', 'DL' => 'SYNTHETIC-LICENSE',
            'State' => 'OH', 'DOB_Month' => '1', 'DOB_Day' => '2', 'DOB_Year' => '2000',
            'training_completion' => (string)(time() - DAYSECS),
            'BTW_Range_Clock_Hours' => '12.5', 'BTW_Road_Clock_Hours' => '9.25',
            'Training_State' => 'OH', 'Training_Zip' => '00000',
            'Training_Street' => 'Synthetic address', 'Training_City' => 'Test city',
        ];
        foreach ($values as $name => $value) {
            $this->profile_value($student->id, $name, $value);
        }
        $providerid = $DB->insert_record('local_govreporting_providers', (object)[
            'name' => 'Synthetic provider', 'locationid' => '00000000-0000-4000-8000-000000000001',
            'components' => 'Theory,Range,PublicRoad', 'testmode' => 1, 'enabled' => 1, 'legacytheory' => 0,
        ]);
        set_config('tpr_theory_provider_id', $providerid, 'local_govreporting');
        set_config('tpr_btw_provider_id', $providerid, 'local_govreporting');
        return $student;
    }

    /**
     * Placeholder groups cannot become government Internal IDs.
     */
    public function test_placeholder_group_blocks_submission(): void {
        $student = $this->student();
        $this->profile_value($student->id, 'Group', 'Please Select Cohort');
        $this->expectException(\invalid_parameter_exception::class);
        data_manager::require_student_group($student->id);
    }

    /**
     * Range hours are independent from theory scores and contain only the assigned Group.
     */
    public function test_range_payload_uses_actual_hours(): void {
        $student = $this->student();
        $payload = (new btw_manager())->payload($student, 'Range');
        $element = $payload['TrainingElements'][0];
        $this->assertSame(12.5, $element['Hours']);
        $this->assertSame('Training group', $element['InternalId']);
        $this->assertSame('Range', $element['TrainingType']);
    }

    /**
     * Later BTW acceptance joins the existing theory card.
     */
    public function test_submitted_components_use_one_card(): void {
        $student = $this->student();
        $manager = new data_manager();
        $manager->record_submission($student->id, 'submitted', 'Synthetic fixture', -101, 'A');
        $manager->record_submission($student->id, 'submitted', 'Synthetic fixture', -103, 'H');
        $btw = new btw_manager();
        $btw->log($student->id, 'A', 'Range', 'submitted', []);
        $cards = $btw->report_students('submitted', [], $manager->get_submitted_students());
        $this->assertCount(1, $cards);
        $this->assertSame((int)$student->id, (int)$cards[0]->id);
        $this->assertCount(2, $cards[0]->submissions);
        $parts = $btw->components($student->id);
        $this->assertTrue($parts[0]['accepted']);
        $this->assertFalse($parts[0]['ready']);
        $this->assertTrue((bool)$parts[1]['ready']);
    }

    /**
     * Theory acceptance does not remove either hours-entry action.
     */
    public function test_theory_acceptance_keeps_hours_buttons(): void {
        global $OUTPUT, $PAGE;
        $student = $this->student();
        $manager = new data_manager();
        $manager->record_submission($student->id, 'submitted', 'Synthetic fixture', -101, 'A');
        $PAGE->set_context(\context_system::instance());
        $PAGE->set_url(new \moodle_url('/local/govreporting/report.php'));
        $cards = $manager->get_submitted_students();
        $view = new output\report_page($cards, 1, null, 'submitted', $manager->get_enabled_bundles());
        $data = $view->export_for_template($OUTPUT);
        $row = $data->students[0];
        $this->assertTrue($row->can_enter_btw_hours);
        $this->assertStringContainsString('component=Range', $row->btw_range_edit_url);
        $this->assertStringContainsString('component=PublicRoad', $row->btw_road_edit_url);
        $this->assertStringContainsString('returntab=submitted', $row->btw_range_edit_url);
    }

    /**
     * A high average does not compensate for a required course below eighty percent.
     */
    public function test_each_required_course_must_pass(): void {
        global $DB;
        $student = $this->student();
        $courses = [];
        $items = [];
        foreach ([80, 90] as $score) {
            $course = $this->getDataGenerator()->create_course();
            $this->getDataGenerator()->enrol_user($student->id, $course->id, 'student');
            $courses[] = $course->id;
            $item = \grade_item::fetch_course_item($course->id);
            $item->grademax = 100;
            $item->grademin = 0;
            $item->update();
            $items[] = $item->id;
            $grade = new \grade_grade(['itemid' => $item->id, 'userid' => $student->id], false);
            $grade->finalgrade = $score;
            $grade->rawgrademax = 100;
            $grade->rawgrademin = 0;
            $grade->insert();
        }
        set_config('curriculum_A', implode(',', $courses), 'local_govreporting');
        $manager = new data_manager();
        $this->assertCount(1, $manager->get_eligible_students());
        $DB->set_field('grade_grades', 'finalgrade', 79, ['itemid' => $items[0], 'userid' => $student->id]);
        $this->clear_report_caches();
        $this->assertSame([], $manager->get_eligible_students());
    }

    /**
     * Approved erasure preserves unrelated students and anonymizes staff references.
     */
    public function test_privacy_erasure_is_scoped(): void {
        global $DB;
        $student = $this->student();
        $other = $this->getDataGenerator()->create_user();
        (new data_manager())->record_submission($student->id, 'submitted', 'Synthetic fixture', -101, 'A');
        $DB->insert_record('local_govreporting_btw', (object)[
            'userid' => $other->id, 'categorycode' => 'B', 'component' => 'Edit', 'status' => 'edited',
            'payload' => '{}', 'response' => '', 'actorid' => $student->id, 'timecreated' => time(),
        ]);
        $context = \context_system::instance();
        $contexts = new approved_contextlist($student, 'local_govreporting', [$context->id]);
        privacy\provider::delete_data_for_user($contexts);
        $this->assertFalse($DB->record_exists('local_govreporting_submissions', ['userid' => $student->id]));
        $this->assertTrue($DB->record_exists('local_govreporting_btw', ['userid' => $other->id, 'actorid' => 0]));
    }
}
