# 1.5.0-beta1 — community release candidate

- Independent Moodle 5.3 installation with configurable curricula and provider locations.
- Creates missing identity, Group, program, training address and actual-hour profile fields; never overwrites existing fields.
- Uses Moodle External API namespaces, GPL metadata, privacy API export/deletion and clean ZIP layout.
- Keeps Group-only Internal ID and one submitted student card across theory/range/road.
- Rejects incomplete identity and completion dates; protects uncertain theory retries.
- Removes obsolete retail configuration pages, development notes, SQL files and theme-specific navigation injection.
- No credentials, student records or site course IDs are distributed.
