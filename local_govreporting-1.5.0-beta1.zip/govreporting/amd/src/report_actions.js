// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Administrator-confirmed theory submission, scoped to the reporting page.
 *
 * @module local_govreporting/report_actions
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import Ajax from 'core/ajax';
import Notification from 'core/notification';
import {get_string as getString} from 'core/str';

/**
 * Display a text-only response without trusting API-provided markup.
 *
 * @param {HTMLElement} root The reporting component.
 * @param {string} message The response to display.
 */
const showError = (root, message) => {
    const output = root.querySelector('#error-message');
    const notice = root.querySelector('#gov-report-error');
    if (output && notice) {
        output.textContent = message;
        notice.style.display = 'block';
    }
};

/**
 * Send a request only after explicit administrator confirmation.
 *
 * @param {HTMLElement} root The reporting component.
 * @param {HTMLButtonElement} button Selected reporting action.
 * @param {number} userid Student ID.
 * @param {number} category Reporting category identifier.
 * @returns {Promise<void>}
 */
const submitStudent = async(root, button, userid, category) => {
    button.disabled = true;
    button.classList.add('processing');
    root.querySelectorAll('#gov-report-success, #gov-report-error').forEach(notice => {
        notice.style.display = 'none';
    });
    try {
        const response = await Ajax.call([{
            methodname: 'local_govreporting_submit_student',
            args: {userid, bundleid: category},
        }])[0];
        if (response.success) {
            window.location.reload();
        } else {
            showError(root, response.message);
        }
    } catch (error) {
        Notification.exception(error);
    } finally {
        button.disabled = false;
        button.classList.remove('processing');
    }
};

/** Initialize the current report once, preserving server-side eligibility checks. */
export const init = () => {
    const root = document.querySelector('.local-govreporting-report');
    if (!root || root.dataset.submissionActionsReady) {
        return;
    }
    root.dataset.submissionActionsReady = '1';
    root.addEventListener('click', async event => {
        const button = event.target.closest('button.submit-student');
        if (!button || !root.contains(button) || button.disabled) {
            return;
        }
        event.preventDefault();
        const userid = Number(button.dataset.userid);
        const category = Number(button.dataset.bundleid);
        if (!Number.isInteger(userid) || userid <= 0 || !Number.isInteger(category) || category === 0) {
            return;
        }
        try {
            const [title, question, yes, no] = await Promise.all([
                getString('pluginname', 'local_govreporting'),
                getString('confirm_submission', 'local_govreporting'),
                getString('yes', 'moodle'),
                getString('no', 'moodle'),
            ]);
            Notification.confirm(title, question, yes, no, () => {
                submitStudent(root, button, userid, category);
            });
        } catch (error) {
            Notification.exception(error);
        }
    });
};
