<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR providers integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_login();
$context = context_system::instance();
require_capability('moodle/site:config', $context);
if (!is_siteadmin()) {
    throw new required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
}
$id = optional_param('id', 0, PARAM_INT);
$edit = optional_param('edit', 0, PARAM_BOOL);
$url = new moodle_url('/local/govreporting/providers.php');
$PAGE->set_context($context);
$PAGE->set_url($url);
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('text_60d1dd3cf66f', 'local_govreporting'));
$PAGE->set_heading(get_string('text_60d1dd3cf66f', 'local_govreporting'));
if ($edit) {
    $record = $id ? $DB->get_record('local_govreporting_providers', ['id' => $id], '*', MUST_EXIST) : null;
    $form = new \local_govreporting\form\provider_form(new moodle_url($url, ['edit' => 1, 'id' => $id]));
    if ($form->is_cancelled()) {
        redirect($url);
    }
    if ($data = $form->get_data()) {
        require_sesskey();
        $components = [];
        foreach (['Theory', 'Range', 'PublicRoad'] as $type) {
            if (!empty($data->{'supports' . $type})) {
                $components[] = $type;
            }
        }
        $save = (object)['name' => trim($data->name),
             'locationid' => trim($data->locationid),
             'components' => implode(
                 ',',
                 $components
             ),

            'enabled' => (int)!empty($data->enabled),
                 'testmode' => (int)!empty($data->testmode),
                 'legacytheory' => $record->legacytheory ?? 0];
        $transaction = $DB->start_delegated_transaction();
        if ($record) {
            $save->id = $record->id;
            $DB->update_record('local_govreporting_providers', $save);
        } else {
            $save->id = $DB->insert_record('local_govreporting_providers', $save);
        }
        $source = (int)$data->credentialsource;
        if ($source === $save->id) {
            $source = 0;
        }
        set_config('credentialsource_' . $save->id, $source, 'local_govreporting');
        // Keep the existing location profile menu compatible with the configured provider names.
        $field = $DB->get_record('user_info_field', ['shortname' => 'Training_Location', 'datatype' => 'menu']);
        if ($field) {
            $options = preg_split('/\r\n|\r|\n/', $field->param1);
            if (!in_array($save->name, $options, true)) {
                $options[] = $save->name;
                $field->param1 = implode("\n", $options);
                $DB->update_record('user_info_field', $field);
            }
        }
        (new \local_govreporting\btw_manager())->log(
            0,
            '',
            'Provider',
            'configured',
            ['before' => $record,
             'after' => $save,
            'certificate_owner' => $source]
        );
        $transaction->allow_commit();
        redirect($url, get_string('text_77e78cd9d2df', 'local_govreporting'));
    }
    if ($record) {
        $record->credentialsource = (int)get_config('local_govreporting', 'credentialsource_' . $record->id);
        foreach (['Theory', 'Range', 'PublicRoad'] as $type) {
            $record->{'supports' . $type} = in_array($type, explode(',', $record->components), true);
        }
        $form->set_data($record);
    }
    echo $OUTPUT->header();
    echo html_writer::div(
        html_writer::link(
            new moodle_url(
                '/admin/category.php',
                ['category' => 'local_govreporting_settings']
            ),
            get_string(
                'text_77fd1c923852',
                'local_govreporting'
            ),
            ['class' => 'btn btn-outline-secondary mb-3']
        ),
        'tpr-report-return'
    );
    $form->display();
    echo $OUTPUT->footer();
    exit;
}
echo $OUTPUT->header();
echo html_writer::div(
    html_writer::link(
        new moodle_url(
            '/admin/category.php',
            ['category' => 'local_govreporting_settings']
        ),
        get_string(
            'text_77fd1c923852',
            'local_govreporting'
        ),
        ['class' => 'btn btn-outline-secondary mb-3']
    ),
    'tpr-report-return'
);
echo html_writer::tag('p', get_string('text_044cb32ecc86', 'local_govreporting'));
echo html_writer::link(
    new moodle_url(
        $url,
        ['edit' => 1]
    ),
    get_string(
        'text_9cec0b2781fe',
        'local_govreporting'
    ),
    ['class' => 'btn btn-primary mb-3']
);
$table = new html_table();
$table->head = [get_string(
    'text_40f3cd24e32f',
    'local_govreporting'
),
     get_string(
         'text_2f62d2686619',
         'local_govreporting'
     ),
     'Environment',
     'Status',
     'Certificate',
     'Actions'];
foreach ($DB->get_records('local_govreporting_providers', null, 'name ASC') as $p) {
    $owner = \local_govreporting\provider_manager::credential_owner($p);
    $shared = $owner && $owner->id !== $p->id;
    $certificate = \local_govreporting\provider_manager::configured($p) ? 'Configured' : get_string(
        'text_811931bba8d1',
        'local_govreporting'
    );
    if ($shared) {
        $certificate .= ' ' . get_string('text_63a83994b390', 'local_govreporting') . ' ' . s($owner->name);
    }
    $actions = html_writer::link(
        new moodle_url(
            $url,
            ['edit' => 1,
            'id' => $p->id]
        ),
        get_string(
            'text_3c692a68d4bc',
            'local_govreporting'
        )
    );
    if (!$shared) {
        $actions .= ' · ' .
             html_writer::link(
                 new moodle_url(
                     '/local/govreporting/btw_credentials.php',
                     ['providerid' => $p->id]
                 ),
                 get_string(
                     'text_a1e3a170a345',
                     'local_govreporting'
                 )
             );
    }
    $table->data[] = [s($p->name) .
         ($p->locationid === '' ? ' ' .
         get_string(
             'text_7627734c9e66',
             'local_govreporting'
         ) : ''),
         s($p->components),
         \local_govreporting\provider_manager::is_testmode($p) ? 'Test' : 'Production',
         $p->enabled ? 'Enabled' : 'Disabled',
         $certificate,
         $actions];
}
echo html_writer::table($table);
echo html_writer::link(
    new moodle_url(
        '/admin/settings.php',
        ['section' => 'local_govreporting_config']
    ),
    get_string(
        'text_8086deea53d9',
        'local_govreporting'
    )
);
echo $OUTPUT->footer();
