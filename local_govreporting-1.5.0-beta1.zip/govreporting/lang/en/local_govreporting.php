<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR lang en local govreporting integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

// Basic plugin strings.
$string['pluginname'] = 'FMCSA TPR Reporting';
$string['reportpage'] = 'Student Report';
$string['settings'] = 'Settings';
$string['tpr_submission'] = 'FMCSA TPR Submission';

// Settings strings.
$string['minscore'] = 'Minimum Score Percentage';
$string['minscoredesc'] = 'The minimum score percentage required for students to be included in the report (default: 80)';
$string['perpage'] = 'Students Per Page';
$string['perpagedesc'] = 'The number of students to display per page (default: 10)';

// FMCSA TPR specific settings.
$string['tpr_settings_heading'] = 'FMCSA TPR Settings';
$string['tpr_settings_desc'] = 'Configure settings for connecting with the FMCSA Training Provider Registry API';
$string['tpr_testmode'] = 'Test Mode';
$string['tpr_testmode_desc'] = 'When enabled, the system will use test credentials and not submit real data to the FMCSA TPR';
$string['tpr_provider_location_id'] = 'Provider Location ID';
$string['tpr_provider_location_id_desc'] = 'The unique identifier for your FMCSA TPR registered location (GUID format)';

// Certificate management.
$string['tpr_certificate_management'] = 'FMCSA TPR Certificate Management';
$string['tpr_certificate_notice'] = 'Certificate Management';
$string['tpr_certificate_notice_desc'] = 'FMCSA TPR requires certificate-based authentication. Please use the <a href="{$a}">Certificate Management</a> page to upload your certificates.';
$string['tpr_certificate_info'] = 'This page allows you to manage the certificates used for FMCSA TPR API authentication. You need to upload the PFX certificate files provided by the FMCSA TPR portal. The system will extract the private keys needed for JWT token signing.';
$string['tpr_certificate_uploaded'] = 'Certificate uploaded and private key extracted successfully';
$string['tpr_certificate_extract_failed'] = 'Failed to extract private key from certificate';
$string['tpr_no_file_uploaded'] = 'No certificate file was uploaded';
$string['tpr_certificate_valid'] = 'Certificate is valid and can be used for JWT signing';
$string['tpr_certificate_invalid'] = 'Certificate is invalid for JWT signing';

// Form field help strings.
$string['tpr_credentialid'] = 'Credential ID';
$string['tpr_credentialid_help'] = 'Enter the issuer ID from your FMCSA TPR credentials. This is typically a GUID provided when you generate your credentials in the FMCSA TPR portal.';
$string['tpr_pfxfile'] = 'PFX Certificate File';
$string['tpr_pfxfile_help'] = 'Upload the .pfx certificate file downloaded from the FMCSA TPR portal or provided in the FMCSA TPR Developer\'s Toolkit.';
$string['tpr_pfxpassword'] = 'PFX Password';
$string['tpr_pfxpassword_help'] = 'Enter the password used to protect the PFX file. This is required to extract the private key.';

// Report page strings.
$string['report_title'] = 'FMCSA TPR Reporting';
$string['report_description'] = 'This report shows students who have scored 80% or higher in ALL their exams and are eligible for FMCSA TPR reporting.';
$string['no_eligible_students'] = 'No eligible students found.';
$string['submit_to_government'] = 'Submit to FMCSA TPR';

// Tab labels.
$string['tab_eligible'] = 'Eligible Students';
$string['tab_submitted'] = 'Submitted Students';

// Submitted students tab.
$string['submitted_description'] = 'This report shows students who have been successfully submitted to the FMCSA TPR database.';
$string['no_submitted_students'] = 'No submitted students found.';
$string['submission_date'] = 'Submission Date';
$string['last_modified'] = 'Last Modified';
$string['attempt_number'] = 'Attempt Number';
$string['first_name'] = 'First Name';
$string['last_name'] = 'Last Name';
$string['driver_license'] = 'Driver License';
$string['date_of_birth'] = 'Date of Birth';
$string['state'] = 'State';
$string['training_completion'] = 'Training Completion Date';
$string['theory_score'] = 'Theory Score (Average)';
$string['courses'] = 'Courses';
$string['exam_scores'] = 'Exam Scores';
$string['actions'] = 'Actions';
$string['showing_students'] = 'Showing students (total: {$a})';
$string['page_x_of_y'] = 'Page {$a->page} of {$a->pages}';

// AJAX response strings.
$string['success_submission'] = 'Successfully submitted to FMCSA TPR database';
$string['error_submission'] = 'Failed to submit to FMCSA TPR database';
$string['confirm_submission'] = 'Are you sure you want to submit this student\'s data to the FMCSA TPR?';

// Capability strings.
$string['govreporting:viewreport'] = 'View FMCSA TPR report';
$string['govreporting:submitdata'] = 'Submit student data to FMCSA TPR';

// Filter strings.
$string['filter_students'] = 'Filter Students';
$string['filter_option_1'] = 'Option 1: Filter by Individual Course';
$string['filter_option_2'] = 'Option 2: Filter by Category Hierarchy';
$string['select_course_directly'] = 'Select any course directly';
$string['select_a_course'] = 'Select a course...';
$string['or_filter_label'] = 'OR';
$string['filter_by_category'] = 'Category';
$string['filter_by_subcategory'] = 'Subcategory';
$string['filter_by_course'] = 'Course in Category';
$string['all_categories'] = 'All Categories';
$string['all_subcategories'] = 'All Subcategories';
$string['all_courses'] = 'All Courses';
$string['all_courses_in_category'] = 'All Courses in Category';
$string['select_category_first'] = 'Select a category first';
$string['apply_filter'] = 'Apply Filter';
$string['clear_filter'] = 'Clear Filter';
$string['loading'] = 'Loading...';

// Bundle configuration strings.
$string['bundle_configuration'] = 'Course Bundle Configuration';
$string['bundle_configuration_desc'] = 'Configure course bundles for FMCSA TPR submissions. A bundle is a group of courses that students must complete together. When all courses in a bundle are completed with 80% or above, the bundle will be submitted to FMCSA TPR with the specified Class/Endorsement Code.';
$string['add_bundle'] = 'Add New Bundle';
$string['edit_bundle'] = 'Edit Bundle';
$string['bundle_name'] = 'Bundle Name';
$string['bundle_category'] = 'Associated Category';
$string['bundle_courses'] = 'Courses in Bundle';
$string['bundle_courses_help'] = 'Hold Ctrl/Cmd to select multiple courses. Students must be enrolled in ALL selected courses and score 80% or above to trigger FMCSA TPR submission.';
$string['bundle_classendorsementcode'] = 'FMCSA TPR Class/Endorsement Code';
$string['bundle_classendorsementcode_help'] = 'Select the FMCSA TPR Class or Endorsement code that this bundle represents. This will be sent to FMCSA TPR when submitting student completion data.';
$string['bundle_enabled'] = 'Enable this bundle';
$string['configured_bundles'] = 'Configured Bundles';
$string['no_bundles_configured'] = 'No bundles have been configured yet. Add a bundle above to get started.';
$string['select_category'] = 'Select a category...';
$string['category'] = 'Category';
$string['status'] = 'Status';
$string['enabled'] = 'Enabled';
$string['disabled'] = 'Disabled';
$string['bundle_created'] = 'Bundle created successfully';
$string['bundle_updated'] = 'Bundle updated successfully';
$string['bundle_deleted'] = 'Bundle deleted successfully';
$string['confirm_delete_bundle'] = 'Are you sure you want to delete this bundle? This action cannot be undone.';
$string['category_not_found'] = 'Category not found';
$string['no_courses'] = 'No courses';
$string['filter_by_bundle'] = 'Bundle';
$string['all_bundles'] = 'All Bundles';
$string['select_bundle'] = 'Select a bundle...';
$string['endorsement_code'] = 'Endorsement Code';

// FMCSA TPR Class/Endorsement codes.
$string['class_endorsement_a'] = 'Class A CDL';
$string['class_endorsement_b'] = 'Class B CDL';
$string['class_endorsement_h'] = 'Hazardous Materials (H)';
$string['class_endorsement_p'] = 'Passenger (P)';
$string['class_endorsement_s'] = 'School Bus (S)';
$string['privacy:metadata:records'] = 'Certification requests, responses, training edits and archive decisions used for FMCSA TPR reporting.';
$string['privacy:metadata:recordfield'] = 'Student or staff reference, training details, status, timestamps, request data or API response associated with the record.';
$string['privacy:metadata:profile'] = 'Identity, Group, program, training dates, hours and address are stored in Moodle custom profile fields and handled by the core user privacy provider.';
$string['privacy:metadata:identity'] = 'Driver license number and state, name, and date of birth.';
$string['privacy:metadata:training'] = 'Category, completion date, training type, score or hours, registered provider location and application type.';
$string['privacy:metadata:group'] = 'The assigned profile Group is sent as the training Internal ID.';
$string['privacy:metadata:external'] = 'An authorized administrator explicitly sends certification data over HTTPS to the United States FMCSA Training Provider Registry. Local erasure does not withdraw or erase government records.';

$string['add_range_hours'] = 'Add BTW Range Hours';
$string['add_road_hours'] = 'Add BTW Road Hours';

// Translatable interface messages for the community release.
$string['text_eb66c5130562'] = 'Already reported outside Moodle';
$string['text_55f2e7d89aa8'] = 'Dismiss from Eligible';
$string['text_ff49ee832131'] = 'Category archived. No government submission was made.';
$string['text_c1b36084c171'] = 'Archive restored. Eligible shows this category if its course requirements are met and it has not been submitted.';
$string['text_09a9c661e9f2'] = 'Unknown archive action';
$string['text_d88f6d2a3111'] = 'FMCSA TPR provider certificate';
$string['text_40f3cd24e32f'] = 'Provider / location';
$string['text_17a150393bd1'] = 'Certificate environment';
$string['text_2a8ebd43b99d'] = 'Test certificate confirmation';
$string['text_fe6bd3955574'] = 'This is an FMCSA-provided test certificate, not a credential generated in my provider portal.';
$string['text_2df791167380'] = 'Credential ID';
$string['text_71bb8b3b4ee5'] = 'PFX certificate';
$string['text_1d65a101ea13'] = 'PFX password';
$string['text_6bcacc410428'] = 'Import provider certificate';
$string['text_f279df6b6bd4'] = 'Provider-portal credentials belong under Production. Test requires an official FMCSA test certificate.';
$string['text_864b5228f94f'] = 'Enter the credential ID supplied by FMCSA TPR.';
$string['text_9c8378446a08'] = 'Select an enabled provider.';
$string['text_c5d087541f0b'] = 'Manage the certificate at the registered provider that owns it.';
$string['text_eb7f65489c24'] = 'Invalid environment';
$string['text_6e563e0f7dc7'] = 'The certificate could not be opened. Check the file and password.';
$string['text_b6fb00b7c1e5'] = 'FMCSA TPR signing check';
$string['text_cfffdad223d5'] = 'The certificate cannot sign with the required algorithm.';
$string['text_50666f28aa9b'] = 'Certificate imported for the selected registered provider and its shared locations.';
$string['text_77fd1c923852'] = '← Back to FMCSA TPR Reporting setup';
$string['text_654e8e8e3598'] = 'Import a certificate for the selected registered provider. Keys and passwords are never displayed. The temporary uploaded certificate is removed after a successful import; your original local file is unaffected.';
$string['text_80658bf33e49'] = 'Importing a certificate does not send training records or switch the reporting environment.';
$string['text_083fd0a955b6'] = 'Select Production for credentials generated in your FMCSA provider portal. Test is reserved for FMCSA-provided test certificates; the certificate itself determines which FMCSA environment receives a request.';
$string['text_ce701413ab41'] = 'Range and road training';
$string['text_4191cbba7a12'] = 'Select a student';
$string['text_d3857f3b46ca'] = 'Student name';
$string['text_6b9acc705643'] = 'Find students';
$string['text_aaae0226a425'] = 'Showing the first 50 matches. Narrow the name to find more.';
$string['text_909a7b0ac14e'] = 'Return to FMCSA TPR report';
$string['text_afaae5f2954f'] = 'Configure the separate behind-the-wheel provider credentials before reviewing a submission.';
$string['text_e1869e860ada'] = 'Confirm the registered training location.';
$string['text_1c3992d64556'] = 'Another submission is in progress.';
$string['text_bc8824fa7181'] = 'Training details changed since review. Review the current details before submitting.';
$string['text_ce19b75c6fa8'] = 'Test accepted. No production acceptance recorded.';
$string['text_f3a3b50faff0'] = 'public road';
$string['text_cf4c525162f3'] = 'TEST MODE: an acceptance will not mark production training as submitted.';
$string['text_3dc379feb194'] = 'PRODUCTION: confirming sends this certification to FMCSA TPR.';
$string['text_7caa7952073e'] = 'Internal ID (Group):';
$string['text_4c97957328b0'] = '— date of birth';
$string['text_0cfe293a4f34'] = 'hours — completed';
$string['text_fe1d987dfb32'] = 'The API uses the configured registered provider location. The address is retained in the local submission history; it is not an extra API address field.';
$string['text_f3e8b38741ac'] = 'I confirm the configured FMCSA TPR provider location is the registered location for this training.';
$string['text_c28a3b872e2c'] = 'Send test certification';
$string['text_cfd0aefe8496'] = 'Confirm and send to FMCSA TPR';
$string['text_d06962f696d6'] = 'A submission or edit is already in progress for this student.';
$string['text_e493b67a7d54'] = 'Training details saved to the student profile. Accepted certification history is unchanged.';
$string['text_40e2c5259f86'] = 'Saving edits does not change a certification already accepted by FMCSA TPR. Range and road share the profile completion date.';
$string['text_c38510b0ef25'] = 'FMCSA TPR';
$string['text_83b4adee0a7f'] = 'Driver license number';
$string['text_b6633b9034d4'] = 'Birth month (1-12)';
$string['text_92c9a8b3cac2'] = 'Birth day (1-31)';
$string['text_984adebd553e'] = 'Birth year (YYYY)';
$string['text_691706123cca'] = 'Driver license state (two-letter code)';
$string['text_663b036254a4'] = 'Training completion date';
$string['text_f85363553270'] = 'Theory score (calculated from course grades)';
$string['text_60727c429597'] = 'Reporting program';
$string['text_ddb326ab3a3c'] = 'Behind-the-wheel range hours';
$string['text_296c7d168f81'] = 'Behind-the-wheel road hours';
$string['text_5036ddd25e82'] = 'Training provider location';
$string['text_cdc79f61df92'] = 'Please select';
$string['text_3a11922c5d25'] = 'Training state';
$string['text_be2a606b04a7'] = 'Training ZIP code';
$string['text_656c58832fc4'] = 'Training street address';
$string['text_e1784fab6ad0'] = 'Training city';
$string['text_60d1dd3cf66f'] = 'FMCSA TPR providers';
$string['text_77e78cd9d2df'] = 'Provider saved. Credentials and past submissions were not changed.';
$string['text_044cb32ecc86'] = 'Add a row for each registered provider location. Locations of the same registered FMCSA provider share its certificate. Separate registered organizations can manage separate certificates.';
$string['text_9cec0b2781fe'] = 'Add location / provider';
$string['text_2f62d2686619'] = 'Training types';
$string['text_811931bba8d1'] = 'Not configured';
$string['text_63a83994b390'] = '— shared with';
$string['text_3c692a68d4bc'] = 'Edit location';
$string['text_a1e3a170a345'] = 'Manage certificate';
$string['text_7627734c9e66'] = '— location ID needed';
$string['text_8086deea53d9'] = 'Reporting settings';
$string['text_33f5515938f0'] = 'FMCSA TPR Reporting';
$string['text_ef45857bd842'] = 'FMCSA TPR Student Report';
$string['text_9a20896fe95e'] = 'FMCSA TPR Providers & Certificates';
$string['text_f62bd375025a'] = 'Provider locations';
$string['text_4598548629aa'] = 'Manage providers — add or edit multiple locations';
$string['text_ed37d6ef2c4c'] = '. Each location has its own training types and registered location ID. Locations of one registered provider share its certificate and environment.';
$string['text_5a3fd82caf0f'] = 'Select a theory provider';
$string['text_08ffbfda4ed3'] = 'Select a range / road provider';
$string['text_771b534ef560'] = 'Default theory provider';
$string['text_8735583a8927'] = 'Online theory always uses this provider; the student range/road location does not override it.';
$string['text_f8999ee2fc1b'] = 'Default range / road provider';
$string['text_629693cf3aa6'] = 'Used when entering range/road data. Staff can select another configured provider for the actual training location.';
$string['text_49a33a802a9f'] = 'Reporting course requirements';
$string['text_6aef23a00ea1'] = 'Select the courses required for each reporting category. Each selected course must meet at least 80%. Empty mappings do not create theory eligibility.';
$string['text_65ea6ad132c8'] = 'Class A';
$string['text_78fcc50b6093'] = 'Class B';
$string['text_d6d6c26958c0'] = 'Hazardous Materials';
$string['text_bdbf8ae5c96f'] = 'School Bus';
$string['text_13f2b260be37'] = 'Restricted Class A';
$string['text_c821899da829'] = 'required courses';
$string['text_7c7448eeb4d3'] = 'Public road';
$string['text_d7deab6523d0'] = 'Select a training provider';
$string['text_a11319cc4f20'] = 'Not entered';
$string['text_ad4eb1aafda6'] = 'Accepted by FMCSA TPR';
$string['text_151ed3674fc6'] = 'Check prior submission outcome before retrying';
$string['text_ae47925b5a09'] = 'Ready for administrator review';
$string['text_909bf22df10b'] = 'Training details incomplete';
$string['text_6138ec0a3a23'] = 'Invalid training component';
$string['text_8bd1eb16214c'] = 'Training is incomplete or already accepted.';
$string['text_f4a49874ced3'] = 'Complete the student identity profile fields first.';
$string['text_ceb18bb9bc81'] = 'Invalid date of birth';
$string['text_269ae47a5295'] = 'License state must use a two-letter state code.';
$string['text_c383fd799f02'] = 'Configure the behind-the-wheel provider location before submitting.';
$string['text_1f93a97c3f1c'] = 'Assign a Group in the student profile before submitting to FMCSA TPR. Please Select Cohort is not a valid group.';
$string['text_715845d2f942'] = 'Missing reporting curriculum';
$string['text_9b805f4ced25'] = 'This reporting category is no longer eligible.';
$string['text_6e14f68a4897'] = 'Invalid or disabled certificate owner.';
$string['text_c4a1be8f6073'] = 'Missing credential ID for JWT token generation';
$string['text_e4f91d22a3cf'] = 'Missing private key for JWT token generation';
$string['text_f908016d4cb9'] = '-----BEGIN PRIVATE KEY-----';
$string['text_52a46ee6d66e'] = '-----END PRIVATE KEY-----';
$string['text_76b43e2d0a72'] = 'Failed to sign JWT:';
$string['text_10430ff704a3'] = 'Unknown OpenSSL error';
$string['text_25cebe11e783'] = 'FMCSA TPR API credentials not configured. Please upload a certificate in the FMCSA TPR Certificate Management page.';
$string['text_5e9420bddd9f'] = 'Invalid student data provided';
$string['text_7518b20eafe6'] = 'Student data missing required fields (firstname, lastname)';
$string['text_dc6c89e03562'] = 'Failed to encode student data to JSON:';
$string['text_e5fd9aa24c94'] = 'Unknown error';
$string['text_bedfe9f17219'] = 'Training data successfully submitted to FMCSA TPR';
$string['text_b53b4e99eae3'] = 'HTTP Error:';
$string['text_8c51ee1cedb4'] = 'Failed to connect to FMCSA TPR API: No HTTP response code';
$string['text_60e1c886a00e'] = 'Enter a valid past training completion date.';
$string['text_3fd26578fc19'] = 'Configure the Online CDL Training provider location before submitting theory.';
$string['text_67d22f59ffd1'] = 'Theory score must be between 80 and 100.';
$string['text_656b5e2718ab'] = 'Complete the license number, license state and valid date of birth.';
$string['text_0a92e9e0dd0b'] = 'new hampshire';
$string['text_836490826951'] = 'new jersey';
$string['text_a91fef9e6c45'] = 'new mexico';
$string['text_dddd9606dd43'] = 'new york';
$string['text_9da9fe9ec69d'] = 'north carolina';
$string['text_6e0bd61eb435'] = 'north dakota';
$string['text_fd1dca9e1aa8'] = 'rhode island';
$string['text_42e4fefb0994'] = 'south carolina';
$string['text_76b559c2d6d1'] = 'south dakota';
$string['text_0cab3c410d5f'] = 'west virginia';
$string['text_62e4b481d0cb'] = 'district of columbia';
$string['text_2ed3972fccfc'] = 'washington dc';
$string['text_945545faf33c'] = 'User ID to submit';
$string['text_65803f250750'] = 'Reporting category identifier';
$string['text_5b7573ac7b69'] = 'Whether the submission was successful';
$string['text_637841f6e1ce'] = 'Success or error message';
$string['text_57b0efb967df'] = 'Response code from the API';
$string['text_0a492f902def'] = 'Another submission is in progress for this student.';
$string['text_7107ed8b8109'] = ': Student not found or not eligible';
$string['text_5510953bd606'] = ': No completed bundles found for this student';
$string['text_748901c4829b'] = ': Specified bundle not found or not completed';
$string['text_f50226d868be'] = 'Select the reporting category to submit.';
$string['text_dd9869797cac'] = 'No course scores available for this reporting category';
$string['text_f106a9973746'] = 'Reconcile the prior uncertain request with FMCSA before retrying.';
$string['text_803fbda0b48c'] = 'Test accepted; no production acceptance recorded';
$string['text_2721f9009853'] = 'Behind-the-wheel training';
$string['text_8373255409bd'] = 'Enter actual completed training. Hours are never filled automatically. The completion date is shared with the student profile.';
$string['text_7829c2bdd074'] = 'Select a provider';
$string['text_870869488ad1'] = 'Range / road provider';
$string['text_183079f3bd54'] = 'Not selected';
$string['text_60dce86db4d6'] = 'Save training details';
$string['text_fcc28c51764a'] = 'Enter zero, positive hours, or leave blank.';
$string['text_bf2829866fe6'] = 'Completion cannot be in the future.';
$string['text_386c15a40f53'] = 'Select a configured range / road provider.';
$string['text_f688853817da'] = 'Provider / location name';
$string['text_5e01632a24e8'] = 'Registered FMCSA TPR location ID';
$string['text_80a1b923b344'] = 'Separate registered provider — manage its own certificate';
$string['text_0c740f10b959'] = 'Same registered provider as:';
$string['text_acb78b0ec870'] = 'Provider certificate';
$string['text_7d45a6c6ed7c'] = 'Locations of the same registered FMCSA provider share one certificate and its environment. A separate registered organization needs its own certificate.';
$string['text_43782b37f011'] = 'Test mode';
$string['text_4455d5ee1b39'] = 'Used only when managing a separate certificate. Shared locations inherit the certificate owner’s environment.';
$string['text_bdf21d238cbf'] = 'Save provider';
$string['text_1f285f1944b6'] = 'Enter the registered location ID from FMCSA TPR.';
$string['text_77d5021d49bd'] = 'Select at least one training type.';
$string['text_e568b6c73469'] = 'Use a unique provider/location name.';
$string['text_ed2ca91c2503'] = 'Select a valid certificate owner without a circular reference.';
$string['text_e81e15339d6e'] = 'One card per student, with all accepted theory, range, and road submissions together, including submissions made at different times.';
$string['text_a8a70d4a60aa'] = 'Students with eligible theory or completed behind-the-wheel training. Each required theory course must reach at least 80%.';
$string['text_d6fbcfc31204'] = 'Archived reporting categories are hidden from Eligible. Archiving is not confirmation from FMCSA TPR.';
$string['text_0eee3e3b29f5'] = 'No archived students found.';
$string['text_b781e616a946'] = 'Not assigned';
$string['text_37add55059e4'] = 'Staff action concerning another record';
$string['text_6412edcd3a06'] = 'Submit student data to government database.';
$string['text_2b84b5ab7f68'] = 'Plugin settings and provider setup';
$string['text_53d2b2b350b1'] = 'Settings / setup';
$string['text_cc0a8d8c7eda'] = 'Archived Students';
$string['text_ab8e089949d1'] = 'Enter range / road training';
$string['text_17e3954e40f3'] = 'Range and road training details can be saved now. Sending requires the separate behind-the-wheel provider location and credentials in';
$string['text_e9aa2e1bc708'] = 'FMCSA TPR settings';
$string['text_7d6b707176ff'] = 'Reporting category';
$string['text_b49a2fc472b8'] = 'All reporting categories';
$string['text_ae9629f4ebb8'] = 'Groups';
$string['text_33c7d0a60fd4'] = 'All groups';
$string['text_ab90d23f7402'] = ' ';
$string['text_aa3dea27391b'] = 'Apply Filter';
$string['text_f641dcde74d7'] = 'Clear Filter';
$string['text_c04773b71e46'] = 'Group:';
$string['text_cd280a41f758'] = 'Edit Profile';
$string['text_2cba22f5bff8'] = 'Enter behind-the-wheel hours';
$string['text_cb3e09f46f59'] = 'Student ID:';
$string['text_5e608719ca82'] = 'Date of birth:';
$string['text_de13bf1ab0b4'] = 'License:';
$string['text_daf52311e2ae'] = 'Average score:';
$string['text_3260f2b5cb7c'] = 'Group required.';
$string['text_c4124190ea7a'] = 'Assign a group using Edit Profile before submitting. “Please Select Cohort” is not a valid group.';
$string['text_76c6cb643d44'] = 'Accepted theory submissions';
$string['text_eaf1cccf1257'] = '— attempt';
$string['text_6a73a69feafa'] = 'Course scores below are current Moodle grades, not historical submitted scores.';
$string['text_fd1279536604'] = 'Restore to Eligible';
$string['text_628691455a21'] = 'hours —';
$string['text_f60f81400684'] = 'Provider:';
$string['text_e29a79fe0c34'] = 'Review';
$string['text_4da0c3de19e7'] = 'submission';
$string['text_44dfb68ef94b'] = 'Edit training details';
$string['text_5aedee0964c6'] = 'hours';
$string['text_af4a14ec4fdb'] = '— completed';
$string['text_2c40d059145b'] = 'Courses & scores (';
$string['text_9ea42a2c2d64'] = 'Course Name';
$string['text_489f4877244a'] = 'Score';
$string['text_c7ae23e8e1dd'] = 'Theory score:';
$string['text_8b127c58209e'] = 'Assign a Group before submitting';
$string['text_3b3d959125ce'] = 'Submit to FMCSA TPR';
$string['text_e873058109f8'] = 'Archive reason';
$string['text_2621c6fd51a5'] = 'Archive';

$string['credentials_required'] = 'Configure provider credentials before submitting training.';
