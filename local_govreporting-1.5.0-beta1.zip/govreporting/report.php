<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * FMCSA TPR report integration.
 *
 * @package local_govreporting
 * @copyright 2025 Original plugin contributors
 * @copyright 2026 ELDT Academy, LLC
 * @license https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// Security checks.
require_login();
$context = context_system::instance();
require_capability('local/govreporting:viewreport', $context);

// Get pagination parameters.
$page = max(0, optional_param('page', 0, PARAM_INT));    // Current page number.
$tab = optional_param('tab', 'eligible', PARAM_ALPHA);
if (!in_array($tab, ['eligible', 'submitted', 'archived'], true)) {
    $tab = 'eligible';
}
if ($tab === 'archived' && !is_siteadmin()) {
    throw new required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
} // Current tab (eligible or submitted)

// Get filter parameters.
$bundleid = optional_param('category', 0, PARAM_INT); // Bundle filter.
$initials = [
    'firstinitial' => strtoupper(optional_param('firstinitial', '', PARAM_ALPHA)),
    'lastinitial' => strtoupper(optional_param('lastinitial', '', PARAM_ALPHA)),
];
foreach ($initials as $key => $value) {
    if (!preg_match('/^[A-Z]$/', $value)) {
        $initials[$key] = '';
    }
}

$initials['group'] = optional_param('group', '', PARAM_RAW_TRIMMED);

// Get configured students per page.
$perpage = max(1, min(100, (int)get_config('local_govreporting', 'perpage')));
if (empty($perpage)) {
    $perpage = 10; // Default if not set.
}

// Setup page.
$PAGE->set_context($context);
$urlparams = array_merge(['page' => $page, 'tab' => $tab], $initials);
if ($bundleid) {
    $urlparams['category'] = $bundleid;
}
$PAGE->set_url(new moodle_url('/local/govreporting/report.php', $urlparams));
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('report_title', 'local_govreporting'));
$PAGE->set_heading(get_string('report_title', 'local_govreporting'));

// Add necessary JS for the page.
$PAGE->requires->js_call_amd('local_govreporting/report_actions', 'init');

// Add page CSS.
// Plugin styles.css is included in the theme stylesheet; avoid a duplicate cached copy.

echo $OUTPUT->header();

// Get the data manager.
$datamanager = new \local_govreporting\data_manager();

// Prepare filter options.
$filters = [
    'bundleid' => $bundleid,
    'group' => $initials['group'],
    'firstinitial' => $initials['firstinitial'],
    'lastinitial' => $initials['lastinitial'],
];

// Combine theory and behind-the-wheel components before student pagination.
if ($tab === 'archived') {
    $allstudents = $datamanager->get_archived_students(0, 0, $filters);
} else {
    $allstudents = $tab === 'submitted' ? $datamanager->get_submitted_students(0, 0, $filters)
        : $datamanager->get_eligible_students(0, 0, $filters);
    $allstudents = (new \local_govreporting\btw_manager())->report_students($tab, $filters, $allstudents);
}
$totalcount = count($allstudents);
$students = array_slice($allstudents, $page * $perpage, $perpage);

// Get list of all enabled bundles for filter dropdown.
$bundles = $datamanager->get_enabled_bundles();

// Setup pagination.
$baseurlparams = array_merge(['tab' => $tab], $initials);
if ($bundleid) {
    $baseurlparams['category'] = $bundleid;
}
$baseurl = new moodle_url('/local/govreporting/report.php', $baseurlparams);
$pagingbar = new paging_bar($totalcount, $page, $perpage, $baseurl);

// Output the page content.
$output = $PAGE->get_renderer('local_govreporting');
$reportpage = new \local_govreporting\output\report_page(
    $students,
    $totalcount,
    $pagingbar,
    $tab,
    $bundles,
    $bundleid,
    $initials
);

echo '<div id="report-content">';
echo $output->render($reportpage);
echo '</div>';

echo $OUTPUT->footer();
