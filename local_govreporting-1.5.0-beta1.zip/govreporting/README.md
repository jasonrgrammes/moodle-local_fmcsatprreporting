# FMCSA TPR Reporting for Moodle

FMCSA TPR Reporting is a free GPL-3.0-or-later local plugin for authorized US driver-training providers. It assists staff in preparing and manually submitting training certifications to the FMCSA Training Provider Registry (TPR). It is independently developed and is not an official FMCSA or Moodle product.

## Release and requirements

- Community candidate 1.5.0-beta1; component: local_govreporting.
- Moodle 5.3, with its supported PHP/database requirements and PHP OpenSSL and cURL.
- No RemUI, Edwiser, paid plugin, Composer installation, or core modification is required.
- Moodle 5.3/MySQL/PHP 8.3 is the intended verification environment. Other database engines require additional runtime testing before they are advertised as tested.
- FMCSA provider registration, registered location IDs, and appropriate FMCSA-issued API credentials are required for actual submissions.

## Features

- Eligible, Submitted and Archived views; one collapsible card per student.
- Class A, Class B, Hazardous Materials, Passenger and School Bus theory reporting.
- Separate behind-the-wheel Range and Public Road records for A/B/P/S, using real profile hours. Hazmat does not generate BTW reports.
- Each configured required course must meet at least the configured threshold (never below 80%). Course mappings are configured locally and start empty.
- First/last-name alphabet rows, dynamic Group filter, Group beside the name, and Edit Profile links.
- Internal ID contains only the current assigned Group. Placeholder groups block submission.
- Configurable multiple registered provider locations; locations of the same registered provider can share credentials. Separate registered providers can have separate credentials.
- Staff enter training details; only site administrators send government requests. Manual confirmation is required. No automatic reporting task is installed.
- Accepted components leave Eligible; later components join the same Submitted card. Reversible archive decisions are local and do not claim government acceptance.
- BTW request snapshots and training edit audit; uncertain requests block blind retries.

## Installation

1. Back up the Moodle database, code and data directory. For a new installation, use Site administration > Plugins > Install plugins and upload the ZIP. Alternatively extract its single govreporting folder to local/govreporting (under public/local/govreporting in Moodle 5.1+ layouts).
2. Complete Site administration > Notifications. Missing profile fields are created in the FMCSA TPR category; existing fields and values are never overwritten. No providers, credentials, students or course mappings are preloaded.
3. Open Site administration > Plugins > Local plugins > FMCSA TPR Reporting > Settings. Configure the required courses for each category and the default theory/BTW providers.
4. Add each registered provider location, select its supported training components, and enter its own FMCSA location ID. Share a certificate only between locations belonging to the same registered provider.
5. Import the correct PFX and issuer ID on the provider certificate page. The import verifies local signing only and sends no records. Private keys are stored in protected Moodle configuration; secure database access and backups. The PFX password is not retained.
6. Use the official FMCSA-provided test certificate for test mode. FMCSA uses the same HTTPS service endpoint for test and production: the credential determines the environment. A checkbox cannot turn a production certificate into a test certificate. Never import a production certificate into the test credential slot.
7. Under User profile fields, edit the Group menu to add your own group choices. Leave no student on Please Select Cohort. Profile Group is a custom profile field, not a native Moodle cohort or course group. Provider names are added to the training-location menu when a provider is saved.
8. Populate DL, State, DOB_Month, DOB_Day, DOB_Year, CDLProgram and training_completion. For BTW also enter the actual hours and Training_State, Training_Zip, Training_Street and Training_City. Empty hours never become 40 automatically. Field shortnames are an interface contract; do not rename them without updating the integration.
9. Map course grades and verify eligibility against known training records. Test only with synthetic data and official FMCSA test credentials, then explicitly select production when ready.

For an existing private installation, read UPGRADING.md first; this community candidate is not an in-place upgrade of the predecessor with its oversized legacy version number.

## Roles and privacy

The system-context viewreport capability governs access. Staff permissions must be assigned explicitly at the system level where required. Government submission additionally requires the submitdata capability and site-administrator status. Identity fields created by this release are hidden from general profile display and are not included in signup forms. Restrict who can edit reporting profiles and administer credentials.

The plugin declares its local certification records and transfer to FMCSA through Moodle's Privacy API. It supports system-context discovery, export, and approved erasure, including staff references. Core profile-field values are handled by Moodle core. Approved local privacy deletion is destructive; set retention rules with your organization's recordkeeping obligations in mind. Local deletion does not withdraw or erase a certification already held by FMCSA. Routine archive/restore never deletes submitted history.

## Limitations and operations

- This release does not implement government-record corrections or withdrawals, automatic submission, or acceptance notification email. Confirmations shown here are based on stored HTTP results and are not a live government reconciliation service.
- The BTW training address is preserved in the local request audit. The API request identifies the registered provider location; it does not append an unsupported address field.
- Remote timeouts can leave an uncertain outcome. Reconcile with FMCSA before clearing a pending/unknown record or resubmitting. An accepted response is never manufactured from a local archive.
- A shared signing credential must be valid for all locations to which it is mapped. Obtain the registered location IDs and credential issuer from FMCSA.
- No personal information or credentials should be attached to a public bug report.

## Source, support and contribution

The source is included in this package. Suggested repository name: moodle-local_govreporting. Before public listing, the maintainer must publish the source/support/documentation locations, supply anonymized screenshots, complete Moodle Marketplace's current automated checks, and address reviewer feedback. The candidate is not pre-approved by Moodle Marketplace.

Maintainer: ELDT Academy, LLC. Original private implementation contributors are credited by their existing GPL attribution; the placeholder author in the predecessor was not a verified identity. Confirm the original authorship record before publishing attribution.

## License

GPL version 3 or later. See LICENSE. No third-party code libraries, student records, private keys, certificates, database dumps or site configuration are bundled.

## References

- https://tpr.fmcsa.dot.gov/Learn/DeveloperToolkit
- https://moodledev.io/docs/5.3/apis/subsystems/privacy
- https://docs.moodle.org/503/en/Plugins_FAQ

## Public support

Source: https://github.com/jasonrgrammes/moodle-local_fmcsatprreporting

Bug reports: https://github.com/jasonrgrammes/moodle-local_fmcsatprreporting/issues

Never include student records, certificates, private keys or credentials in a public issue.

Training hours editing requires local/govreporting:edittraining. Submission remains administrator-only.
